/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ESMO GW2GW.
ESMO GW2GW is free software: you can redistribute it and/or modify it under the terms of EUPL 1.2.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/

package eu.esmo.gateway.gw2gw.rest_api.controllers.internal;

import io.swagger.annotations.*;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@javax.annotation.Generated(value = "eu.esmo.gateway.gw2gw.codegen.languages.SpringCodegen", date = "2019-02-04T13:09:09.939Z")

@Api(value = "gw", description = "the gw API")
public interface GwQueryApi {
	
	@ApiOperation(value = "FOR TESTING: Returns a token from SM", nickname = "gwToken", notes = "FOR TESTING: Returns a token from SM", tags={ "Internal GWms APIs", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Request admitted"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/gw/token",
        produces = { "application/x-www-form-urlencoded" },
        method = RequestMethod.GET)
	ResponseEntity<String> gwToken();
	

	@ApiOperation(value = "Pass a standard request object to be handled.", nickname = "gwQuery", notes = "Process a DSA request from the ACM to be sent to the remote GW. Such request can contain the remote AP just discovered or not (to be discovered in the remote GW).", tags={ "Internal GWms APIs", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Request admitted"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/gw/query",
        consumes = { "application/x-www-form-urlencoded" },
        method = RequestMethod.POST)
    String gwQuery(@ApiParam(value = "The security token for ms to ms calls", required=true) @RequestParam(value="msToken", required=true)  String msToken);


    
}
