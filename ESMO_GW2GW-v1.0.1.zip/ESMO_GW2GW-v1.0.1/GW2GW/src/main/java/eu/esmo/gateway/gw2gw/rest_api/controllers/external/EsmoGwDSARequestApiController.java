/**
Copyright © 2019  Atos Spain SA. All rights reserved.
This file is part of ESMO GW2GW.
ESMO GW2GW is free software: you can redistribute it and/or modify it under the terms of EUPL 1.2.
THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT ANY WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT, 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
DAMAGES OR OTHER LIABILITY, WHETHER IN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
See README file for the full disclaimer information and LICENSE file for full license information in the project root.
*/
package eu.esmo.gateway.gw2gw.rest_api.controllers.external;

import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.cm_api.ConfMngrConnService;
import eu.esmo.gateway.gw2gw.rest_api.domain.ApiCallType;
import eu.esmo.gateway.gw2gw.rest_api.domain.MsMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.MsMetadataList;
import eu.esmo.gateway.gw2gw.rest_api.domain.PublishedApiType;
import eu.esmo.gateway.gw2gw.rest_api.services.external.EsmoGwDSARequestService;

import io.swagger.annotations.*;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;


@javax.annotation.Generated(value = "eu.esmo.gateway.gw2gw.codegen.languages.SpringCodegen", date = "2019-02-04T13:09:09.939Z")

@Controller
public class EsmoGwDSARequestApiController {
//public class EsmoGwDSARequestApiController implements EsmoGwDSARequestApi {
	
	@Autowired
	private EsmoGwDSARequestService gwDSARequestService;
	
	@Autowired
	private ConfMngrConnService confMngrConnService;

    private static final Logger log = LoggerFactory.getLogger(EsmoGwDSARequestApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public EsmoGwDSARequestApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }
 
    /*
    @RequestMapping(value = "/TEST", method = {RequestMethod.POST})
    public String myTest(@ApiParam(value = "The Encrypted & Signed JWT Token requesting DSA claims for GW to GW calls", required=true) @RequestParam(value="ESMOToken", required=true)  String esMOToken, 
    		//HttpServletRequest request, HttpServletResponse response, 
    		Model model) {
   	
    	String msToken = "hello, msToken";
        String gwUrl = "http://localhost:8080/gw/response";
        
        model.addAttribute("msToken", msToken);
        model.addAttribute("msUrl", gwUrl );
    	
        return "gwform";
        
        //return new ResponseEntity<String>("testing", HttpStatus.PERMANENT_REDIRECT);

    }
    */
    
    @ApiOperation(value = "Towards the remote GW.", nickname = "gwDSARequest", notes = "Called by the origin GW2GW ms.", tags={ "External GWms endpoints", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Request admitted"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/esmo/gw/dsaRequest",
        consumes = { "application/x-www-form-urlencoded" },
        method = RequestMethod.POST)
    //String gwDSARequest(@ApiParam(value = "The Encrypted & Signed JWT Token requesting DSA claims for GW to GW calls", required=true) @RequestParam(value="esMOToken", required=true)  byte[] esMOToken);
    public String gwDSARequest(@ApiParam(value = "The Encrypted & Signed JWT Token requesting DSA claims for GW to GW calls", required=true) @RequestParam(value="esMOToken", required=true)  String esMOToken,
    		Model model) {
    	
    	//Decipher  and Validate the ESMOtoken (dsaRequest)  *** Jump to gwDSARequest
    	// Example of a dsaRequest JWT:
		
//		{
//			"iss":"https://origGWurl.com:4040/esmo/gw/dsaResponse", 
//			"aud":["https://destGWurl.com/:4040/esmo/gw/dsaRequest"], 
//			"iat": "1364292137871",
//			"exp": "1364293137871",
//			"nbf": "1364292537871",
//			"jti":"345a7bab-de06-4695-a2dd-9d8d6b40e443",   //Callback reference
//			"spEntityId": "https://www.strath.ac.uk",
//			"apEntityId": "https://esmo.uji.es",
//			"eIDAS_entityId": "https://esmo.uji.es/gw/saml/idp/metadata.xml"
//			"eIDAS_displayNames" : {"ES" : "UJI Proveedor de Identidad","EN" : "UJI Identity Provider"},
//			"eIDAS_loa": "High",
//			"eIDAS_PersonIdentifier":["ES/AT/02635542Y"], 
//			"eIDAS_FamilyName":["Jones Welsh","J Welsh"], 
//			"eduPersonAffiliation":null,
//			"eduPersonOrgUnitDN":null
//			}
    	
    	// Extract info to build the following:
    	// * spRequest, 
    	// * spMetadata (1. spEntityId, 2. oGW apiCallback endpoint address), TO ASK
    	// * apEntityId (it could be null, so the tACM could invoke the MultiUI
    	// * authenticationSet
    	
    	// LOG the above variables just extracted.
    	
    	// Start Session: POST /sm/startSession
    		// Sets up an internal session temporary storage and returns its identifier
    		// by setting the code to NEW and the identifier at sessionData.sessionId
    	 
    	// Update session data: POST /sm/updateSessionData
    	// Passed data is stored in a session variable overwriting the previous value. 
    	// If no session variable is given, then the whole data stored in this session will be replaced with the passed dataObject. 
    	// In that case the dataObject must be a dictionary containing pairs of key, values e.g. {key1:value1, key2:value2} 
    	// with keys and values strings (the latter may be json)
    	// Responds by setting code = OK "

    	// To store spRequest, spMetadata (oGW apiCallback endpoint address TO ASK),apEntityId, authenticationSet   

    	// Store also the UUID of this GW2GW ms in a GW2GW_ID_SESSION_VAR?? I don't think so.
    	// TO ASK

    	// Create msToken: GET /sm/generateToken
    	    // Generates a signed token, only the sessionId as the payload, 
    	    // additionaly parameters include: The id of the requesting microservice (msA) and The id of the destination microservice (msB), may also include additional data
    	    // Responds by code: New, additionalData: the jwt token
    	    	
    	//Return from gwDSAResponse
    	
    	// Redirect to /acm/attributes/request with the msToken. 
    	
    	// END
    	
    	
    	//String accept = request.getHeader("Accept");
    	String contentType = request.getHeader("Content-type");
    	if (contentType != null && contentType.contains("application/x-www-form-urlencoded")) {
        	
	        try {
	        	
	        	// Decipher and validate the ESMOtoken (dsaRequest)
	        	String msToken = gwDSARequestService.gwDSARequest(esMOToken);
	        	
	        	if (msToken != null) {
		        	// Redirect to /acm/attributes/request with the msToken
	        		
	        		String acmUrl = null;
	        		boolean found = false;
	        		MsMetadataList myACMs = confMngrConnService.getMicroservicesByApiClass("ACM"); 
	        		for (MsMetadata acm : myACMs) {
	        			for (PublishedApiType apiType : acm.getPublishedAPI() ) {
	        				if (apiType.getApiCall () == ApiCallType.valueOf("acmRequest")) {
	        					acmUrl = apiType.getApiEndpoint();
	        					found = true;
	        					break;
	        			}
	        			if (found) break;
	        			}
	        		}
	        						
					if (acmUrl != null) {
					
						//System.out.println ("acmUrl: " + acmUrl);
						model.addAttribute("msToken", msToken);
						model.addAttribute("msUrl", acmUrl );
		        	
						return "gwform";
					} else {
						log.error("Error getting the msUrl: " + acmUrl);
						return "error";
					}
	        	}
	        	else {
	        		log.error("Error generating the msToken: " + msToken);
	        		return "error";
	        	}
	        		        
	        	
	        }
	        catch (Exception e) {
	            log.error("Exception: ", e);
	            
	            //return new ResponseEntity<String>(HttpStatus.UNAUTHORIZED);
	            return "error";
	        	
	        }
        
    	}
        
    	log.error("Bad content-type.");
    	return "error";
    	//return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
    	
        
    }

	


}



/* REDIRECT: the body is not changed.
URI location = new URI("http://localhost:8070/cm/metadata/microservices"); //GET
// URI location = new URI("http://localhost:8050/gw/query"); //POST
   HttpHeaders responseHeaders = new HttpHeaders();
   responseHeaders.setLocation(location);
   //responseHeaders.setAllow (HttpMethod.POST);
   responseHeaders.set("apiClass", "SP");
   //responseHeaders.set("msToken", "MMMM");  // EXPECTED IN THE BODY, NOT IN THE HEADER!

   return new ResponseEntity<String>(responseHeaders, HttpStatus.PERMANENT_REDIRECT);
*/
