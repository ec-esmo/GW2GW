package eu.esmo.gateway.gw2gw.rest_api.services.external;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import eu.esmo.gateway.gw2gw.cm_api.ConfMngrConnService;
import eu.esmo.gateway.gw2gw.configuration.Constants;
import eu.esmo.gateway.gw2gw.params_api.KeyStoreService;
import eu.esmo.gateway.gw2gw.params_api.ParameterService;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSet;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSetStatus;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeType;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSetStatus.CodeEnum;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadataList;
import eu.esmo.gateway.gw2gw.rest_api.domain.SecurityKeyType;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;

@Service
public class EsmoGwDSAResponseServiceImp implements EsmoGwDSAResponseService{
	
	private static final Logger log = LoggerFactory.getLogger(EsmoGwDSAResponseServiceImp.class);
	
	private AttributeSet dsResponse;
				
	private EntityMetadata dsMetadata;
	
	@Autowired
	private SessionManagerConnService smConn;
	
	@Autowired
	private ConfMngrConnService confMngrConnService;
	
	@Autowired
	private KeyStoreService keyStoreService;
	
	@Autowired
	private ParameterService paramServ;
	
	@Override
	public String gwDSAResponse (String ESMOToken)  throws Exception {
				
		//System.out.println ("We are in /esmo/gw/dsaResponse with token: " + ESMOToken);
		
		String msToken=null;
		
		try {
		
		// Example of a dsaResponse JWT:

//		{
//			"iss":"https://destGWurl.com",  	
//			"aud":["https://origGWurl.com"], 
//			"iat": "1364292138971",
//			"exp": "1364294138971",
//			"nbf": "1364292538971",
//			"jti":"345a7bab-de06-4695-a2dd-9d8d6b40e443",   // The gwCallback reference, to retrieve the sessionId
//			"status":{"code":"200","subcode":"","message":""}
//			"apEntityId": "https://esmo.uji.es/gw/saml/ap/attributeService/metadata.xml", 
//			"eduPersonAffiliation":["faculty","student"],
//			"eduPersonOrgUnitDN":{"ou":"potions","o":"Hogwarts","dc":"hsww","dc":"wiz"},
//			"schacHomeOrganization":"tut.fi"
//			"notBefore": "2019-12-06T19:40:16Z", 
//			"notAfter": "2019-12-06T19:45:16Z"
//			}
		
			SignedJWT signedJwt = null;
			
			if (paramServ.getParam("RSA_CIPHERED_ESMOTOKEN").equals ("true")) {
				
				//
				//Decipher  
				//
				
				//log.info ("ESMOToken with encryption...");
				
				// Parse the JWE string
				JWEObject jweObject = JWEObject.parse(ESMOToken);
	
				// Decrypt with private key
				jweObject.decrypt(new RSADecrypter((PrivateKey) keyStoreService.getJWEKey()));
	
				// Extract payload
				signedJwt = jweObject.getPayload().toSignedJWT();
				
				if (signedJwt == null) {
					log.error("Payload is not a signed JWT!");
					return null;
				}
					
			}
			else  {
				//log.info ("ESMOToken withOUT encryption...");
				signedJwt = SignedJWT.parse(ESMOToken);
			}
			
			//SignedJWT signedJwt = SignedJWT.parse(new String(ESMOToken, StandardCharsets.UTF_8));
			//SignedJWT signedJwt = SignedJWT.parse(ESMOToken);
			
	    	
			// Extract info to build the following:
	    	// * dsResponse
	    	// * dsMetadata
			// * gwCallback: jti
			
			JWTClaimsSet jwtClaims = signedJwt.getJWTClaimsSet();
			
			//Getting callback reference
			String gwCallback = jwtClaims.getStringClaim ("jti");
			
			// Get Session: GET /sm/getSession
			String sessionId = smConn.getSession("gwCallback", gwCallback);
			// So, checked whether "jti" == gwCallback sessionData
			if (sessionId != null) {
			
			dsResponse = new AttributeSet();
			dsResponse.setId(Constants.ESMO_GW2GW_PREFIX + UUID.randomUUID().toString());
			
			//dsResponse.setIssuer (jwtClaims.getStringClaim ("iss"));
			dsResponse.setIssuer (jwtClaims.getStringClaim ("apEntityId"));
			dsResponse.setType(AttributeSet.TypeEnum.RESPONSE);
			dsResponse.setInResponseTo(gwCallback);
			dsResponse.setNotAfter(jwtClaims.getStringClaim ("notAfter"));
			dsResponse.setNotBefore(jwtClaims.getStringClaim ("notBefore"));
			
			//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
	    	Object objSpRequest = smConn.readVariable(sessionId, "spRequest");
	    	AttributeSet spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);
			dsResponse.setRecipient (spRequest.getId()); // sPentityID from the spRequest
			
			AttributeSetStatus myStatus = new AttributeSetStatus();
			String myStringStatus = jwtClaims.getStringClaim("status");
			//System.out.println ("myStringStatus:" + myStringStatus);
			
			JsonObject myJSONstatus = new JsonParser().parse(myStringStatus).getAsJsonObject();
			
			//myStatus.setCode(CodeEnum.fromValue(myJSONstatus.get("code").toString()));
			//System.out.println ("myStringStatus CODE: " + myJSONstatus.get("code").toString());
			String codeWithoutQuotes = myJSONstatus.get("code").toString();
			codeWithoutQuotes = codeWithoutQuotes.replaceAll("^\"|\"$", "");
			//myStatus.setCode(myJSONstatus.get("code") != null ? CodeEnum.fromValue(myJSONstatus.get("code").toString()) : null);
			myStatus.setCode(myJSONstatus.get("code") != null ? CodeEnum.valueOf(codeWithoutQuotes) : null);
			myStatus.setSubcode(myJSONstatus.get("subcode") != null ? myJSONstatus.get("subcode").toString() : null);
			myStatus.setMessage(myJSONstatus.get("message") != null ? myJSONstatus.get("message").toString() : null);
			
			dsResponse.setStatus (myStatus);
			
			List<AttributeType> myResponseAttributes =  new ArrayList<AttributeType>();
			String key= "";
			int counter = 0;
			Set<String> fixedClaims = new HashSet<String>(
				       Arrays.asList("iss", "aud", "iat", "exp", "nbf", "jti", "status", "apEntityId", "notBefore", "notAfter"));

			String withoutBracketsEtAll;
			for ( Map.Entry<String, Object> entry : jwtClaims.getClaims().entrySet()) {
	             
				key = entry.getKey();
	            if (!fixedClaims.contains(key) ) {
	            	 AttributeType anAttribute = new AttributeType ();
	            	 anAttribute.setFriendlyName(key);
	            	 withoutBracketsEtAll= "";
	            	 withoutBracketsEtAll = entry.getValue()!=null ? entry.getValue().toString() : null;
	            	 if (withoutBracketsEtAll != null) {
	            		 withoutBracketsEtAll = withoutBracketsEtAll.replaceAll("\\[|\\]", "");
	            		 withoutBracketsEtAll = withoutBracketsEtAll.replaceAll("^\"|\"$", "");
	            		 withoutBracketsEtAll = withoutBracketsEtAll.replaceAll ("\\\\","");
	            	 }
	            	 //log.info ("withoutBracketsEtAll: " + withoutBracketsEtAll);
	            	 anAttribute.addValuesItem(withoutBracketsEtAll);
	            	 myResponseAttributes.add(counter++, anAttribute);
	            }	            
	        }
			dsResponse.setAttributes(myResponseAttributes);
			
			dsMetadata = new EntityMetadata();
			// just the ApEntityId
			dsMetadata.setEntityId(jwtClaims.getStringClaim ("apEntityId"));

			
			// LOG the above variables just extracted.
//			log.info("Data obtained to be stored in the Session ...");
//			log.info ("dsResponse:" + "\n" + dsResponse.toString());
//			log.info ("dsMetadata:" + "\n" + dsMetadata.toString());
//			
//			log.info ("gwCallback:" + gwCallback);
			
			
			
			
			
			//
			// Verification of the ESMOToken
			//
				// Verify the signature with the issuer's public key!!
			
			// Check the issuer, among the ones allowed.
			// 1.- Check that the entity ID belongs to the entityID of ESMO gateways published in 
			// EWP Registry / EntityMetadata of that GW 
			boolean validated = false;
			String publicK = null;
			String remoteGWId = jwtClaims.getIssuer();
			EntityMetadataList myGWentityList = confMngrConnService.getEntityMetadataSet("rGW");
			if (myGWentityList != null) {
			 for (EntityMetadata gw : myGWentityList) {
				
					if (gw.getEntityId().equals(remoteGWId))  {
						
						// Select the recipient public key
						for (SecurityKeyType secKey : gw.getSecurityKeys()) {
							if (secKey.getUsage().equals(SecurityKeyType.UsageEnum.SIGNING)) {
								publicK = secKey.getKey();
								//System.out.println ("publicK:" + publicK);
							}
						}
						validated = true;
						break;
				}
				
			 }
			}
			if (!validated) {
				log.error("Issuer " + remoteGWId + " is not authorised.");
				return msToken;
			}
			if (publicK == null) {
				 log.error("No remote GW public key to validate the signature of the ESMOToken!");
				 return null;
			 }
			
			// From String to RSAPublicKey
			//byte[] publicBytes = Base64.getDecoder().decode(publicK);
			byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes("UTF-8"));
			//byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes());
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
	        
			 
			 JWSVerifier verifier = new RSASSAVerifier(pubKey);			
			//JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) getPublicKey());  //Local testing
			// NOOO JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) keyStoreService.getJWTPublicKey());

			if (signedJwt.verify(verifier)) {
				log.info ("ESMOToken signature verified! Expiration time is not validated yet.");
				//jwtClaims.getExpirationTime()
			
				
				
				// Validate the JWT
				
				// Check the audience. It could be the gw entity Id or the sp entity id... Mmmmm TO ASK: they are entityIDs?? YES
				// Therefore, FROM THE ConfMngr: to check both files and if not found then reject the jwt: redirect "error";
				//validated = false;
				
				if (!validated) {
					
					// It's me or one of my SPs
					String me = confMngrConnService.getConfiguration("LGW").getEntityId();
					List<String> audience = jwtClaims.getAudience();
					for (String entityId : audience) {
						if (entityId.equals(me)) {
							validated = true;
							break;
						}
						
					}
					if (!validated) {
						EntityMetadataList mySPs = confMngrConnService.getEntityMetadataSet("SP");
						if (mySPs != null) {
						 for (String entityId : audience) {
							for (EntityMetadata mySP : mySPs) {
								if (mySP.getEntityId().equals(entityId)) {
									validated = true;
									break;
								}
							}
							if (validated) break;
						 }
						}			
					}
					if (!validated) {
						log.error("Audience: " + audience.toString() + " is not authorised.");
						return msToken;
					}
				
				}
								
				// Other validations: times			
				validated = false;
				//TODO
				//jwtClaims.getIssueTime()
				//jwtClaims.getNotBeforeTime()

				
	    	// Update session data: POST /sm/updateSessionData
		    // To store dsResponse, dsMetadata
			
			ObjectMapper objDsResponse = new ObjectMapper();
			smConn.updateVariable(sessionId,"dsResponse",objDsResponse.writeValueAsString(dsResponse));
			
			ObjectMapper objDsMetadata = new ObjectMapper();
			smConn.updateVariable(sessionId,"dsMetadata",objDsMetadata.writeValueAsString(dsMetadata));
	    	
	    	// Clear the GW2GW callback ref session var
			smConn.updateVariable(sessionId, "gwCallback", "");
	    	
	    	// Generate token: GET /sm/generateToken
			msToken = smConn.generateToken(sessionId); 
			
			}
			else {
				log.error("sessionId is null?!");
			}
			}
			else {
				log.error("ESMOToken signature NOT verified!");
			}
		}
		catch (Exception e) {
			
			log.error("Exception: ", e);
		}
		
		return msToken;
		
	}
	
	
	///
	/// PRIVATE
	///
//	private Key getPublicKey() throws KeyStoreException, FileNotFoundException, IOException,
//													   NoSuchAlgorithmException, CertificateException, 
//													   UnrecoverableKeyException, InvalidKeySpecException 
//		{
//			//[ONLY USED WHEN TESTING] 
//			ClassLoader classLoader = getClass().getClassLoader();
//			String path = classLoader.getResource("testKeys/keystore.jks").getPath();
//			KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
//			File jwtCertFile = new File(path);
//			InputStream certIS = new FileInputStream(jwtCertFile);
//			keystore.load(certIS, "keystorepass".toCharArray());
//				
//			Key key = keystore.getKey("1", "selfsignedpass".toCharArray());
//			
//			if (key instanceof PrivateKey) {
//		          // Get certificate of public key
//		          Certificate cert = keystore.getCertificate("1");
//		          // Get public key
//		          PublicKey publicKey = cert.getPublicKey();
//
//		          //String publicKeyString = Base64.encodeBase64String(publicKey
//		          //          .getEncoded());
//		          String publicKeyString = publicKey.toString();
//		          //System.out.println("PublicKey: "+ publicKeyString);
//		          
//		          return publicKey;
//
//		        }
//			else return null;	
//				
//		}

}

