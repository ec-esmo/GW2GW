package eu.esmo.gateway.gw2gw.rest_api.controllers;

@javax.annotation.Generated(value = "eu.esmo.gateway.gw2gw.codegen.languages.SpringCodegen", date = "2019-02-04T13:09:09.939Z")

public class ApiException extends Exception{
    private int code;
    public ApiException (int code, String msg) {
        super(msg);
        this.code = code;
    }
}
