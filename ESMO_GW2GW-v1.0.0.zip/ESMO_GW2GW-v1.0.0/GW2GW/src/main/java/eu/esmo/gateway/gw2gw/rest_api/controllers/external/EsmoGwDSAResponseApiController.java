package eu.esmo.gateway.gw2gw.rest_api.controllers.external;

import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.cm_api.ConfMngrConnService;
import eu.esmo.gateway.gw2gw.rest_api.domain.ApiCallType;
import eu.esmo.gateway.gw2gw.rest_api.domain.MsMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.MsMetadataList;
import eu.esmo.gateway.gw2gw.rest_api.domain.PublishedApiType;
import eu.esmo.gateway.gw2gw.rest_api.services.external.EsmoGwDSAResponseService;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
@javax.annotation.Generated(value = "eu.esmo.gateway.gw2gw.codegen.languages.SpringCodegen", date = "2019-02-04T13:09:09.939Z")

@Controller
//public class EsmoGwDSAResponseApiController implements EsmoGwDSAResponseApi {
public class EsmoGwDSAResponseApiController {
	
	@Autowired
	private EsmoGwDSAResponseService gwDSAResponseService;
	
	@Autowired
	private ConfMngrConnService confMngrConnService;

    private static final Logger log = LoggerFactory.getLogger(EsmoGwDSAResponseApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public EsmoGwDSAResponseApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    @ApiOperation(value = "Towards the origin GW.", nickname = "gwDSAResponse", notes = "Callback. Pass a standard response object to be handled. Called by the remote GW2GW ms.", tags={ "External GWms endpoints", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Response admitted"),
        @ApiResponse(code = 400, message = "Bad response"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/esmo/gw/dsaResponse",
        consumes = { "application/x-www-form-urlencoded" },
        method = RequestMethod.POST)
    public String gwDSAResponse(@ApiParam(value = "The Encrypted & Signed JWT Token returning DSA claims for GW to GW calls", required=true) @RequestParam(value="esMOToken", required=true)  String esMOToken,
    		Model model) {
    //public ResponseEntity<Void> gwDSAResponse(@ApiParam(value = "The Encrypted & Signed JWT Token returning DSA claims for GW to GW calls", required=true) @RequestParam(value="esMOToken", required=true)  byte[] esMOToken) {
    
    	//Decipher and Validate the ESMOtoken   *** Jump to gwDSAResponse
    	
    	// Example of a dsaResponse JWT:

//		{
//		"iss":"https://destGWurl.com/:4040/esmo/gw/dsaRequest", 
//		"aud":["https://origGWurl.com:4040/esmo/gw/dsaResponse"], 
//		"iat": "1364292138971",
//		"exp": "1364294138971",
//		"nbf": "1364292538971",
//		"jti":"345a7bab-de06-4695-a2dd-9d8d6b40e443",   //Callback reference
//		"status":{"code":"200","subcode":"","message":""}
//		"apEntityId": "https://esmo.uji.es/gw/saml/ap/attributeService/metadata.xml", 
//		"eduPersonAffiliation":["faculty","student"],
//		"eduPersonOrgUnitDN":{"ou":"potions","o":"Hogwarts","dc":"hsww","dc":"wiz"}
//		}
    	
    	// Extract info to build the following:
    	// * dsResponse
    	// * dsMetadata
    	
    	// LOG of the above info
    	
    	// Get Session: GET /sm/getSession
		// Using callback reference
	    	
    	// Update session data: POST /sm/updateSessionData
	    	// Passed data is stored in a session variable overwriting the previous value. 
	    	// If no session variable is given, then the whole data stored in this session will be replaced with the passed dataObject. 
	    	// In that case the dataObject must be a dictionary containing pairs of key, values e.g. {key1:value1, key2:value2} 
	    	// with keys and values strings (the latter may be json)
	    	// Responds by setting code = OK "
    	// To store dsResponse, dsMetadata
    	
    	// Clear the GW2GW callback ref session var: TO ASK
    	
    	// Generate token: GET /sm/generateToken
    	
    	//Return from gwDSAResponse
    	
    	// Redirect to /acm/attributes/response with the msToken
    	
    	// END
    	
    	//String accept = request.getHeader("Accept");
    	String contentType = request.getHeader("Content-type");
    	if (contentType != null && contentType.contains("application/x-www-form-urlencoded")) {
        	
	        try {

	        	// Decipher and validate the ESMOtoken
	        	String msToken = gwDSAResponseService.gwDSAResponse(esMOToken);
	        	
	        	if (msToken!=null) {
		        	
		        	String acmUrl = null;
	        		boolean found = false;
	        		MsMetadataList myACMs = confMngrConnService.getMicroservicesByApiClass("ACM"); 
	        		for (MsMetadata acm : myACMs) {
	        			for (PublishedApiType apiType : acm.getPublishedAPI() ) {
	        				if (apiType.getApiCall () == ApiCallType.valueOf("acmResponse")) {
	        					acmUrl = apiType.getApiEndpoint();
	        					found = true;
	        					break;
	        			}
	        			if (found) break;
	        			}
	        		}
	        						
					if (acmUrl != null) {
					
						//System.out.println ("acmUrl: " + acmUrl);
						model.addAttribute("msToken", msToken);
						model.addAttribute("msUrl", acmUrl );
		        	
						return "gwform";
						//return new ResponseEntity<Void>(HttpStatus.OK);
					} else {
						log.error("Error getting the msUrl: " + acmUrl);
						return "error";
					}
	        	}
	        	else {
	        		log.error("Error generating the msToken: " + msToken);
	        		return "error";
	        	}
	        }
	        catch (Exception e) {
	            log.error("Exception: ", e);
	        	
	            return "error";
	        	//return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
	        }
        
    	}
        
    	log.error("Bad content-type.");
    	return "error";
    	//return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        
        
    }
    
        
}
