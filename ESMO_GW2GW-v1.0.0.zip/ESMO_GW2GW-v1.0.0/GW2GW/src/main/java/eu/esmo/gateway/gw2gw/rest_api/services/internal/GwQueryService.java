package eu.esmo.gateway.gw2gw.rest_api.services.internal;

import eu.esmo.gateway.gw2gw.rest_api.domain.TokenToGw;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;

public interface GwQueryService {
	
	TokenToGw gwQuery (SessionManagerConnService smConn, String sessionId) throws Exception;

}
