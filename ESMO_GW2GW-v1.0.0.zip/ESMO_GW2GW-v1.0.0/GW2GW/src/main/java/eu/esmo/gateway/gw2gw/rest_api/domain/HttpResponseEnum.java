package eu.esmo.gateway.gw2gw.rest_api.domain;

/**
*
* @author nikos
*/
public enum HttpResponseEnum {
   AUTHORIZED,
   UN_AUTHORIZED,
   HEADER_MISSING,
   BAD_REQUEST;
}