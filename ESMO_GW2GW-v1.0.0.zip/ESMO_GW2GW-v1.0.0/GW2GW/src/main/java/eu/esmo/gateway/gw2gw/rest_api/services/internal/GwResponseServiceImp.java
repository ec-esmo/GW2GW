package eu.esmo.gateway.gw2gw.rest_api.services.internal;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import eu.esmo.gateway.gw2gw.cm_api.ConfMngrConnService;
import eu.esmo.gateway.gw2gw.configuration.Constants;
import eu.esmo.gateway.gw2gw.params_api.KeyStoreService;
import eu.esmo.gateway.gw2gw.params_api.ParameterService;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSet;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSetList;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSetStatus;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeType;
import eu.esmo.gateway.gw2gw.rest_api.domain.EndpointType;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.SecurityKeyType;
import eu.esmo.gateway.gw2gw.rest_api.domain.TokenToGw;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;

@Service
public class GwResponseServiceImp implements GwResponseService{
	
	private static final Logger log = LoggerFactory.getLogger(GwResponseServiceImp.class);
	
	@Autowired
	private ConfMngrConnService confMngrConnService;
	
	private AttributeSetList responseAssertions;
	
	private EntityMetadata idpMetadata;
	
	private EntityMetadata spMetadata;
	
	private AttributeSet spRequest;
	
	@Autowired
	private TokenToGw tokenToGw;
	
	@Autowired
	private KeyStoreService keyStoreService;
	
	@Autowired
	private ParameterService paramServ;
	
	@Override
	public TokenToGw gwResponse (SessionManagerConnService smConn, String sessionId)  throws Exception {
				
		//System.out.println ("We are in /gw/response with sessionId: " + sessionId);	
		
		// Get SessionData: GET /sm/sessionData
    	// Get responseAssertions (AttributeSetList), 
    	// and where is the oGW callback?? in spRequest (spRequest.Id: stored before calling ACM)
		// and the endpoint?? in spMetadata
		
		String ESMOToken = null;
		String originGwEndpoint = null; 	
		
		try {
			
//// *** TEST
//			AttributeSet mySpRequest = new AttributeSet(); 
//			mySpRequest.setId( Constants.ESMO_GW2GW_PREFIX + UUID.randomUUID().toString()); // It is the origin GW callback, the jti
//			mySpRequest.setType(AttributeSet.TypeEnum.REQUEST); 
//			mySpRequest.setIssuer( "originSP in the oGW");
//			mySpRequest.setRecipient("this remoteGW");
//			
//			ObjectMapper objMapper = new ObjectMapper();
//			smConn.updateVariable(sessionId, "spRequest", objMapper.writeValueAsString(mySpRequest));
//			
//			AttributeSet myResponse = new AttributeSet();
//			myResponse.setId( "ACM_" + UUID.randomUUID().toString());
//			myResponse.setType(AttributeSet.TypeEnum.RESPONSE);
//			myResponse.setIssuer( "https://esmo.uji.es/gw/saml/ap/attributeService/metadata.xml"); // apEntityId
//			myResponse.setRecipient("oGW?");
//			myResponse.setInResponseTo("whatever");
//			
//			AttributeSetStatus myStatus = new AttributeSetStatus();
//			myStatus.setCode (AttributeSetStatus.CodeEnum.OK);
//			myStatus.setMessage("This is the status message.");
//			myResponse.status(myStatus);
//			
//			myResponse.setNotAfter("2019-12-06T19:45:16Z");
//			myResponse.setNotBefore("2018-12-06T19:45:16Z");
//			
//			List<AttributeType> myRespAttributes =  new ArrayList<AttributeType>();
//			AttributeType anRespAttribute = new AttributeType ();
//			anRespAttribute.setEncoding("plain");
//			anRespAttribute.setFriendlyName("eduPersonAffiliation");
//			anRespAttribute.setName("http://xxxx/attributes/attr1");
//			anRespAttribute.setLanguage(null);
//			anRespAttribute.setIsMandatory(true);
//			anRespAttribute.addValuesItem("MARY"); //["faculty","student"] TODO
//			myRespAttributes.add(0, anRespAttribute);
//			
//			AttributeType anRespAttribute2 = new AttributeType ();
//			anRespAttribute2.setEncoding("plain");
//			anRespAttribute2.setFriendlyName("eduPersonOrgUnitDN");
//			anRespAttribute2.setName("http://xxxx/attributes/attr2");
//			anRespAttribute2.setLanguage(null);
//			anRespAttribute2.setIsMandatory(true);
//			anRespAttribute2.addValuesItem("Dr"); // {"ou":"potions","o":"Hogwarts","dc":"hsww","dc":"wiz"} TODO
//			myRespAttributes.add(1, anRespAttribute2);
//			
//			myResponse.setAttributes(myRespAttributes);
//			
//			AttributeSetList myResponseList = new AttributeSetList();
//			myResponseList.add(myResponse);
//			ObjectMapper objMapper2 = new ObjectMapper();
//			smConn.updateVariable(sessionId, "responseAssertions", objMapper2.writeValueAsString(myResponseList));
//			
////			ObjectMapper objMapper3 = new ObjectMapper();
////			smConn.updateVariable(sessionId, "originGwId", objMapper3.writeValueAsString("this is the originGwId"));
//			
//			EntityMetadata myIdpMetadata = new EntityMetadata();
//			myIdpMetadata.setEntityId("https://pasarela.clave.gob.es/ProxyClave2/ServiceProvider/metadata");
//			myIdpMetadata.setDefaultDisplayName("Clave Gateway eIDAS SPAIN");
//			
//			ObjectMapper objMapper4 = new ObjectMapper();
//			smConn.updateVariable(sessionId, "idpMetadata", objMapper4.writeValueAsString(myIdpMetadata));
//			
//			EntityMetadata mySpMetadata = new EntityMetadata();
//			mySpMetadata.setEntityId("https://esmo.uji.es/gw/saml/sp/vleSP/metadata.xml");
//			List<EndpointType> endpoints = new ArrayList<EndpointType> ();
//			EndpointType originGW = new EndpointType();
//			originGW.setUrl("http://5.79.83.118:8050/esmo/gw/dsaResponse"); 
//			originGW.setMethod("HTTP-POST");
//			originGW.setType(Constants.ESMO_GW_DSARESPONSE);
//			endpoints.add(originGW);
//			
//			mySpMetadata.setEndpoints(endpoints);
//			
//			List<SecurityKeyType> secKeys = new ArrayList<SecurityKeyType> ();
//			SecurityKeyType sigKey = new SecurityKeyType();
//			sigKey.setKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCi7jZVwQFxQ2SY4lxjr05IexolQJJobwYzrvE5pk7AcQpG46kuJBzD8ziiqFFCGSNZ07cLWys+b5JmJ6kU44lKLVeGbEpgaO0OTBDLMk2fi5U83T8dezgWgaPFiy/N3sHPpcW2Y3ZePo0UbM7MLzv14TR+jxTOyrmwWwGwDJsz+wIDAQAB");
//			sigKey.setKeyType("RSAPublicKey");
//			sigKey.setUsage(SecurityKeyType.UsageEnum.SIGNING);
//			secKeys.add(sigKey);
//			
//			SecurityKeyType sigKey2 = new SecurityKeyType();
//			sigKey2.setKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCi7jZVwQFxQ2SY4lxjr05IexolQJJobwYzrvE5pk7AcQpG46kuJBzD8ziiqFFCGSNZ07cLWys+b5JmJ6kU44lKLVeGbEpgaO0OTBDLMk2fi5U83T8dezgWgaPFiy/N3sHPpcW2Y3ZePo0UbM7MLzv14TR+jxTOyrmwWwGwDJsz+wIDAQAB");
//			sigKey2.setKeyType("RSAPublicKey");
//			sigKey2.setUsage(SecurityKeyType.UsageEnum.ENCRYPTION);
//			secKeys.add(sigKey2);
//			
//			mySpMetadata.setSecurityKeys(secKeys);
//			
//			
//			ObjectMapper objMapper5 = new ObjectMapper();
//			smConn.updateVariable(sessionId, "spMetadata", objMapper5.writeValueAsString(mySpMetadata));
//			
//// ***END TEST
			
			
			// LOG sessionData to be obtained obtained
	    	//log.info("SessionData obtained ...");
		
			//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
			Object objResponseAssertions = smConn.readVariable(sessionId, "responseAssertions");
			// It could be null!!
			
			if (objResponseAssertions != null) {
			
				responseAssertions = (new ObjectMapper()).readValue(objResponseAssertions.toString(),AttributeSetList.class);
				//log.info ("responseAssertions - ONLY ONE attributeSet:" + "\n" + responseAssertions.toString());
			}
	    	
	    	//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
	    	Object objSpRequest = smConn.readVariable(sessionId, "spRequest");
	    	spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);

	    	Object objSpMetadata = smConn.readVariable(sessionId, "spMetadata");
	    	spMetadata = (new ObjectMapper()).readValue(objSpMetadata.toString(),EntityMetadata.class);
	    	
	    	Object objIdpMetadata = smConn.readVariable(sessionId, "idpMetadata");
	    	idpMetadata = (new ObjectMapper()).readValue(objIdpMetadata.toString(),EntityMetadata.class);    	    	
	    	
	    	
//	    	log.info ("spRequest:" + "\n" + spRequest.toString());
//	    	log.info ("spMetadata:" + "\n" + spMetadata.toString());
//	    	log.info ("idpMetadata:" + "\n" + idpMetadata.toString());
//			System.out.println ("originGwId: " + originGwId);
			
			// Select the recipient public key
			String publicK = null;
			for (SecurityKeyType secKey : spMetadata.getSecurityKeys()) {
					 if (secKey.getUsage().equals(SecurityKeyType.UsageEnum.ENCRYPTION)) {
						 publicK = secKey.getKey();
						 //System.out.println("ENCRYPTING WITH SP-GW-'s: " + publicK);
					 }
			}
			if (publicK == null) {
				 log.error("No remote GW public key to encrypt the ESMOToken!");
				 return null;
			 }
			
			// Select the endPoint
			List<EndpointType> myEndPoints = spMetadata.getEndpoints();
			for (EndpointType endPoint : myEndPoints) {
				if (endPoint.getType().equals(Constants.ESMO_GW_DSARESPONSE)) {
					originGwEndpoint = endPoint.getUrl();
					break;
				}
			}
			//log.info ("AWARE ***originGwEndpoint: " + originGwEndpoint);
		
		// Build ESMOToken (dsaResponse) with the attribute assertions
		
		
		// Example of a dsaResponse JWT:
		
//		{
//			"iss":"https://destGWurl.com",  	// entityIDs: To be retrieved from the responseAssertions 
//			"aud":[NO"https://origGWurl.com"], 	// from the session data: spMetadata!!
//			"iat": "1364292138971",
//			"exp": "1364294138971",
//			"nbf": "1364292538971",
//			"jti":"345a7bab-de06-4695-a2dd-9d8d6b40e443",   // The gwCallback reference, TO BE RETRIEVED FROM THE spRequest id
//			"status":{"code":"200","subcode":"","message":""} , from the responseAssertions
//			"apEntityId": "https://esmo.uji.es/gw/saml/ap/attributeService/metadata.xml", 
//			"eduPersonAffiliation":["faculty","student"],
//			"eduPersonOrgUnitDN":{"ou":"potions","o":"Hogwarts","dc":"hsww","dc":"wiz"},
//			"schacHomeOrganization":"tut.fi",
//			"notBefore": "2019-12-06T19:40:16Z", from the responseAssertions
//			"notAfter": "2019-12-06T19:45:16Z"
//
//			}

			// Compose the JWT claims set
			Date now = new Date();			
						
			JWTClaimsSet.Builder jwtClaimsBuilder = new JWTClaimsSet.Builder()
						.expirationTime(new Date(now.getTime() + 1000*60*10)) // expires in 10 minutes
						.notBeforeTime(now)
						.issueTime(now)
						.jwtID(spRequest.getId());
						
			
			// Adding custom claims:
			jwtClaimsBuilder = jwtClaimsBuilder.issuer(confMngrConnService.getConfiguration("LGW").getEntityId()); // retrieved from the internal configuration
			//jwtClaimsBuilder = jwtClaimsBuilder.claim ("audience", Arrays.asList(originGwId));
			jwtClaimsBuilder = jwtClaimsBuilder.audience(Arrays.asList(spMetadata.getEntityId()));
			
			
			if (objResponseAssertions != null) {
			
				AttributeSetStatus status = responseAssertions.get(0).getStatus();
				Gson gson = new Gson();
				String jsonStatus = gson.toJson(status);
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("status", jsonStatus);
				//System.out.println("status: "+ jsonStatus);
				
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("apEntityId", responseAssertions.get(0).getIssuer()); //Only one
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("notBefore", responseAssertions.get(0).getNotBefore());
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("notAfter", responseAssertions.get(0).getNotAfter());
				
				
				// Adding .claim for responseAssertions
				for ( AttributeType anAttribute : responseAssertions.get(0).getAttributes())
				{
					jwtClaimsBuilder = jwtClaimsBuilder.claim (anAttribute.getFriendlyName(), anAttribute.getValues());
								
				}
			
			}
			else {
				//log.info("responseAssertions does not exist...");
				AttributeSetStatus myStatus = new AttributeSetStatus();
				myStatus.setCode (AttributeSetStatus.CodeEnum.OK);
				myStatus.setSubcode("NO ATTRIBUTES RETRIEVED");
				myStatus.setMessage("No attributes retrieved.");
				Gson gson = new Gson();
				String jsonStatus = gson.toJson(myStatus);
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("status", jsonStatus);
								
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("apEntityId", "");
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("notBefore", "");
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("notAfter", "");
				
				
			}

			JWTClaimsSet jwtClaims = jwtClaimsBuilder.build();
			
			// LOG initial ESMOToken just built
			//System.out.println("GOOD jwtClaims just build: " + jwtClaims.toJSONObject(true)); // there are fields to "null"
			//System.out.println("jwtClaims just build: " + jwtClaims.toString()); // without null fields
//			log.info("JWT just build: " + jwtClaims.toJSONObject(true).toString());
			
			// Sign using service account private key
			
			// Header must contain algorithm ("alg") and key ID ("kid")
			 JWSHeader jwsHeader =
			   //new JWSHeader.Builder(JWSAlgorithm.RS256).keyID("1").build(); // PrivateKeyId is alias
					 new JWSHeader.Builder(keyStoreService.getAlgorithm()).keyID(paramServ.getParam("JWT_CERT_ALIAS")).build();
			 
			// Create RSA-signer with the private key
			//JWSSigner signer = new RSASSASigner((PrivateKey) getPrivateKey());  //Local testing
			 JWSSigner signer = new RSASSASigner((PrivateKey) keyStoreService.getJWTSigningKey());
			 
			 SignedJWT signedJwt = new SignedJWT(jwsHeader, jwtClaims);
			 signedJwt.sign(signer);
			 
			 //ESMOToken = signedJwt.serialize();
			 //System.out.println("signedJWT compacted: " + signedJwt.serialize());

			 if (paramServ.getParam("RSA_CIPHERED_ESMOTOKEN").equals ("true")) {
				 //
				 // ENCRYPTION
				 //
				 
				// Create JWE object with signed JWT as payload
				 JWEObject jweObject = new JWEObject(
				     new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM) // Supposed the recipient accepts it TODO
				         .contentType("JWT") // required to indicate nested JWT
				         .build(),
				     new Payload(signedJwt));
	
				 // Encrypt with the recipient's public key
				 RSAKey recipientPublicJWK = null;

				 // From String to RSAPublicKey
				 byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes("UTF-8"));
				 //byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes());
				 X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
				 KeyFactory keyFactory = KeyFactory.getInstance("RSA");
				 RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
				 
				 // Convert to JWK format
				 recipientPublicJWK= new RSAKey.Builder(pubKey).build();

				 jweObject.encrypt(new RSAEncrypter(recipientPublicJWK));
	
				 //log.info ("ESMOToken with encryption...");
				 // Serialise to JWE compact form
				 ESMOToken = jweObject.serialize();
				 //System.out.println("jweObject compacted: " + jweObject.serialize());
			 }
			 else {
				 //log.info ("ESMOToken withOUT encryption...");
				 ESMOToken = signedJwt.serialize();
			 }
			
			
		
		}
		catch (Exception e) {
			
			log.error("Exception: ", e);
		}
		
		tokenToGw.setEsMOToken(ESMOToken);
		tokenToGw.setGwEndpoint(originGwEndpoint); 
		
		return tokenToGw;
		
	}
	
	///
	/// PRIVATE
	///
//	private Key getPrivateKey() throws KeyStoreException, FileNotFoundException, IOException,
//													   NoSuchAlgorithmException, CertificateException, 
//													   UnrecoverableKeyException, InvalidKeySpecException 
//	{
//				//[ONLY USED WHEN TESTING] 
//				ClassLoader classLoader = getClass().getClassLoader();
//				String path = classLoader.getResource("testKeys/keystore.jks").getPath();
//				KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
//				File jwtCertFile = new File(path);
//				InputStream certIS = new FileInputStream(jwtCertFile);
//				keystore.load(certIS, "keystorepass".toCharArray());
//				
//				return(keystore.getKey("1", "selfsignedpass".toCharArray()));
//				
//				
//	}

}

