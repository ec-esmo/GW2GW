package eu.esmo.gateway.gw2gw.configuration;

public class Constants {
	private Constants() {}
	
	
	public final static String ESMO_GW_DSAREQUEST = "dsaRequest"; 
	public final static String ESMO_GW_DSARESPONSE = "dsaResponse"; 
	//public final static String ESMO_GW_REQUEST = "/acm/request";
	//public final static String ESMO_GW_RESPONSE = "/acm/response";
	
	public final static String ESMO_GW2GW_PREFIX = "GW2GW_";
	
	public final static String XXXX_NOT_FOUND = "xxxx not found";
	
}
