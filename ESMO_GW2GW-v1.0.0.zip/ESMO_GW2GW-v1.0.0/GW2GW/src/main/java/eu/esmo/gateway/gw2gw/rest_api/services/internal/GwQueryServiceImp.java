package eu.esmo.gateway.gw2gw.rest_api.services.internal;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.cm_api.ConfMngrConnService;
import eu.esmo.gateway.gw2gw.configuration.Constants;
import eu.esmo.gateway.gw2gw.params_api.KeyStoreService;
import eu.esmo.gateway.gw2gw.params_api.ParameterService;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeType;
import eu.esmo.gateway.gw2gw.rest_api.domain.EndpointType;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSet;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadataList;
import eu.esmo.gateway.gw2gw.rest_api.domain.TokenToGw;
//import eu.esmo.gateway.gw2gw.rest_api.domain.EsmoManifest;
import eu.esmo.gateway.gw2gw.rest_api.domain.SecurityKeyType;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;

import java.util.*;

import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.*;
//import com.nimbusds.jose.jwk.KeyUse;
//import com.nimbusds.jose.jwk.RSAKey;
//import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.jwk.*;
import com.nimbusds.jwt.*;


@Service
public class GwQueryServiceImp implements GwQueryService{
	
	private static final Logger log = LoggerFactory.getLogger(GwQueryServiceImp.class);
	
	@Autowired
	private ConfMngrConnService confMngrConnService;
	
	private AttributeSet apRequest;
	private AttributeSet spRequest;
		
	private EntityMetadata idpMetadata;
	
	private String apEntityId;
		
	private AttributeSet authenticationSet;
	
	@Autowired
	private TokenToGw tokenToGw;
	
	@Autowired
	private KeyStoreService keyStoreService;
	
	@Autowired
	private ParameterService paramServ;
	
	@Override
	public TokenToGw gwQuery (SessionManagerConnService smConn, String sessionId)  throws Exception {
		
		String ESMOToken = null;
		String remoteGwEndpoint = null; //apRequest says which remoteGW or remoteAP: EntityId
		
		
//		// *** TEST
//		AttributeSet mySpRequest = new AttributeSet();
//		mySpRequest.setId( "SP_" + UUID.randomUUID().toString());
//		mySpRequest.setIssuer( "https://esmo.uji.es/gw/saml/idp/metadata.xml");
//		mySpRequest.setType(AttributeSet.TypeEnum.REQUEST);
//		
//		
//		ObjectMapper objMapper0 = new ObjectMapper();
//		smConn.updateVariable(sessionId, "spRequest", objMapper0.writeValueAsString(mySpRequest));
//		
//		AttributeSet myApRequest = new AttributeSet();
//		myApRequest.setId( "AP_" + UUID.randomUUID().toString());
//		myApRequest.setType(AttributeSet.TypeEnum.REQUEST);
//		myApRequest.setIssuer( "ACMms001");
//		//myApRequest.setRecipient("GW2GWms001"); // Testing the apEntityId
//		myApRequest.setRecipient("https://5.79.83.118:8080/cm/entity/GWmetadata.json");
//		
//		List<AttributeType> myAttributes =  new ArrayList<AttributeType>();
//		AttributeType anAttribute = new AttributeType ();
//		//anAttribute.setEncoding("plain");
//		anAttribute.setFriendlyName("FirstREMOTEAttr");
//		anAttribute.setName("FirstREMOTEAttr");
//		//anAttribute.setLanguage(null);
//		//anAttribute.setIsMandatory(true);
//		//anAttribute.addValuesItem("JOHN");
//		myAttributes.add(0, anAttribute);
//		
//		AttributeType anAttribute2 = new AttributeType ();
//		//anAttribute.setEncoding("plain");
//		anAttribute2.setFriendlyName("SecondREMOTEAttr");
//		anAttribute2.setName("SecondREMOTEAttr");
//		//anAttribute.setLanguage(null);
//		//anAttribute.setIsMandatory(true);
//		//anAttribute.addValuesItem("ES/NO/1234ABCD");
//		myAttributes.add(1, anAttribute2);
//		
//		myApRequest.setAttributes(myAttributes);
//		
//		ObjectMapper objMapper = new ObjectMapper();
//		smConn.updateVariable(sessionId, "apRequest", objMapper.writeValueAsString(myApRequest));
//		
//		
//		
//		AttributeSet myAuth = new AttributeSet();
//		myAuth.setId( "AP_" + UUID.randomUUID().toString());
//		myAuth.setType(AttributeSet.TypeEnum.AUTHRESPONSE); 
//		myAuth.setIssuer( "uji.es");
//		myAuth.setRecipient("remoteGW2GWms001");
//		myAuth.setLoa("http://eidas.europa.eu/LoA/substantial");
//		myAuth.setNotAfter("2018-12-06T19:45:16Z");
//		myAuth.setNotBefore("2018-12-06T19:40:16Z");
//		 
//		List<AttributeType> myAuthAttributes =  new ArrayList<AttributeType>();
//		AttributeType anAuthAttribute = new AttributeType ();
//		anAuthAttribute.setEncoding("plain");
//		anAuthAttribute.setFriendlyName("CurrentGivenName");
//		anAuthAttribute.setName("http://eidas.europa.eu/attributes/naturalperson/CurrentGivenName");
//		anAuthAttribute.setLanguage(null);
//		anAuthAttribute.setIsMandatory(true);
//		anAuthAttribute.addValuesItem("JOHN JOHN");
//		myAuthAttributes.add(0, anAuthAttribute);
//		
//		AttributeType anAuthAttribute2 = new AttributeType ();
//		anAuthAttribute2.setEncoding("plain");
//		anAuthAttribute2.setFriendlyName("PersonIdentifier");
//		anAuthAttribute2.setName("http://eidas.europa.eu/attributes/naturalperson/PersonIdentifier");
//		anAuthAttribute2.setLanguage(null);
//		anAuthAttribute2.setIsMandatory(true);
//		anAuthAttribute2.addValuesItem("ES/NO/1234ABCD");
//		myAuthAttributes.add(1, anAuthAttribute2);
//		
//		myAuth.setAttributes(myAuthAttributes);
//		
//		EntityMetadata myIdp = new EntityMetadata();
//		myIdp.setEntityId("https://pasarela.clave.gob.es/ProxyClave2/ServiceProvider/metadata");
//		myIdp.setDefaultDisplayName("Clave Gateway eIDAS SPAIN");
//		
//		ObjectMapper objMapper2 = new ObjectMapper();
//		smConn.updateVariable(sessionId, "authenticationSet", objMapper2.writeValueAsString(myAuth));
//		
//		ObjectMapper objMapper21 = new ObjectMapper();
//		smConn.updateVariable(sessionId, "idpMetadata", objMapper21.writeValueAsString(myIdp));
//		
//				
////		ObjectMapper objMapper3 = new ObjectMapper();
////		//smConn.updateVariable(sessionId, "apEntityId", objMapper3.writeValueAsString("https://5.79.83.118:8080/cm/entity/GWmetadata.json")); //the remote one
////		smConn.updateVariable(sessionId, "apEntityId", objMapper3.writeValueAsString("HELLO")); // The remote AP is specified
//		
//		// ***END TEST
		
		
		
		try {
		
			// Get SessionData: GET /sm/getSessionData
	    	// Get apRequest (AttributeSet), --YESSS apMetadata (EntityMetadata)--, --NO apEntityId from ACM--, authenticationSet (AttributeSet)
	    	
	    	//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
			Object objSpRequest = smConn.readVariable(sessionId, "spRequest");
	    	spRequest = (new ObjectMapper()).readValue(objSpRequest.toString(),AttributeSet.class);
	    	
	    	Object objApRequest = smConn.readVariable(sessionId, "apRequest");
	    	apRequest = (new ObjectMapper()).readValue(objApRequest.toString(),AttributeSet.class);
	    	
//	    	Object objApEntityId = smConn.readVariable(sessionId, "apEntityId");
//	    	apEntityId = (new ObjectMapper()).readValue(objApEntityId.toString(),String.class);
	    	
	    	Object objApMetadata = smConn.readVariable(sessionId, "apMetadata");
	    	EntityMetadata apMetadata = (new ObjectMapper()).readValue(objApMetadata.toString(),EntityMetadata.class);
	    	
	    	apEntityId = apMetadata.getEntityId();
	    	
	    	Object objAuthenticationSet = smConn.readVariable(sessionId, "authenticationSet");
	    	authenticationSet = (new ObjectMapper()).readValue(objAuthenticationSet.toString(),AttributeSet.class);
	    	
	    	Object objIdpMetadata = smConn.readVariable(sessionId, "idpMetadata");
	    	idpMetadata = (new ObjectMapper()).readValue(objIdpMetadata.toString(),EntityMetadata.class);
	    	
	    	
	    	
	    	// LOG sessionData just obtained
//	    	log.info("SessionData obtained ...");
//	    	log.info ("spRequest:" + "\n" + spRequest.toString());
//	    	log.info ("apRequest:" + "\n" + apRequest.toString());
//	    	log.info ("apEntityId:" + "\n" + apEntityId);
//	    	log.info ("authenticationSet:" + "\n" + authenticationSet.toString());
//	    	log.info ("idpMetadata:" + "\n" + idpMetadata.toString());
	    	
	    	// Look for the remoteGW apiEndpoint, and its publicKey
	    	boolean found = false;
	    	String publicK = null;
			
			// Searching among the remote GWs
			EntityMetadataList possibleGWs = confMngrConnService.getEntityMetadataSet("rGW"); 
			if (possibleGWs != null) {
				for (EntityMetadata gw : possibleGWs) {
					//log.info("possibleGWs apRequest.getRecipient(): " + apRequest.getRecipient());		
					
				  if (gw.getEntityId().equals (apRequest.getRecipient())) {
					
					  // Select the recipient public key
					  for (SecurityKeyType secKey : gw.getSecurityKeys()) {
							 if (secKey.getUsage().equals(SecurityKeyType.UsageEnum.ENCRYPTION)) {
								 publicK = secKey.getKey();
								 //System.out.println("ENCRYPTING WITH rGW's: " + publicK);
							 }
					  }
								 
					  List<EndpointType> myEndPoints = gw.getEndpoints();
					  for (EndpointType endPoint : myEndPoints) {
							if (endPoint.getType().equals(Constants.ESMO_GW_DSAREQUEST)) {
								remoteGwEndpoint = endPoint.getUrl();
								found = true;
								break;
							}
					  }
					  if (found) break;
					}
				}
			}
			
			// Searching among the remote APs
			if (!found) { // The remote AP could be specified.
				EntityMetadataList possibleAPs = confMngrConnService.getEntityMetadataSet("rAP"); 
				if (possibleAPs != null) {
					for (EntityMetadata ap : possibleAPs) {
						//log.info("possibleAPs apEntityId: " + apEntityId);
						
						if (ap.getEntityId().equals(apEntityId)) {
							
							// Select the recipient public key
							for (SecurityKeyType secKey : ap.getSecurityKeys()) {
								if (secKey.getUsage().equals(SecurityKeyType.UsageEnum.ENCRYPTION)) {
										 publicK = secKey.getKey();
										 //System.out.println("ENCRYPTING WITH rAP's: " + publicK);
								}
							}
							
							List<EndpointType> myEndPoints = ap.getEndpoints();
							for (EndpointType endPoint : myEndPoints) {
								if (endPoint.getType().equals(Constants.ESMO_GW_DSAREQUEST)) {
									remoteGwEndpoint = endPoint.getUrl();
									found = true;
									break;
								}
							}
							if (found) break;
							
						}
					}
				}
				  
			}
			
			if (publicK == null) {
				 log.error("No remote GW public key to encrypt the ESMOToken!");
				 return null;
			 }
			
			//log.info("remoteGwEndpoint: " + remoteGwEndpoint);
			tokenToGw.setGwEndpoint(remoteGwEndpoint);
			
			
			// Build ESMOToken (dsaRequest)
	    	
			
		// Example of a dsaRequest JWT:
		
//		{
//		"iss":"https://origGWurl.com",  	//Entity Id 
//		"aud":["https://destGWurl.com"], 	//Entity Id 
//		"iat": "1364292137871",
//		"exp": "1364293137871",
//		"nbf": "1364292537871",
//		"jti":"345a7bab-de06-4695-a2dd-9d8d6b40e443",   //Callback reference
//		"spEntityId": "https://www.strath.ac.uk/ServiceProvider/metadata", 	// Entity Id 
//		"apEntityId": "https://esmo.uji.es/AttributeProvider/metadata",		// Entity Id
//		"IDP_entityId": "https://pasarela.clave.gob.es/ProxyClave2/ServiceProvider/metadata"
//		"IDP_defaultDisplayName" : {"Clave Gateway eIDAS SPAIN"},
//		"eIDAS_loa": "http://eidas.europa.eu/LoA/high",
//		"eIDAS_PersonIdentifier":["ES/AT/02635542Y"], 
//		"eIDAS_FamilyName":["Jones Welsh","J Welsh"], 
//		"eduPersonAffiliation":null,
//		"eduPersonOrgUnitDN":null,
//		"schacHomeOrganization":null

			// Compose the JWT claims set
			Date now = new Date();

			String gwCallback = Constants.ESMO_GW2GW_PREFIX + UUID.randomUUID().toString();
			
			
			JWTClaimsSet.Builder jwtClaimsBuilder = new JWTClaimsSet.Builder()
					
			    .issuer(confMngrConnService.getConfiguration("LGW").getEntityId()) // retrieved from the internal configuration
			    
			    .audience(Arrays.asList(apRequest.getRecipient()))
			    .expirationTime(new Date(now.getTime() + 1000*60*10)) // expires in 10 minutes
			    .notBeforeTime(now)
			    .issueTime(now)
			    .jwtID(gwCallback);
			
			// Adding custom claims:
			jwtClaimsBuilder = jwtClaimsBuilder.claim ("spEntityId", spRequest.getIssuer());
			jwtClaimsBuilder = jwtClaimsBuilder.claim ("apEntityId", apEntityId);
			jwtClaimsBuilder = jwtClaimsBuilder.claim ("IDP_entityId", idpMetadata.getEntityId());
			jwtClaimsBuilder = jwtClaimsBuilder.claim ("IDP_defaultDisplayName", idpMetadata.getDefaultDisplayName());
			
			// Adding .claim for authentication and the requested claims
			for ( AttributeType authAttribute : authenticationSet.getAttributes())
			{
				jwtClaimsBuilder = jwtClaimsBuilder.claim ("eIDAS_" + authAttribute.getFriendlyName(), authAttribute.getValues());
				
			}
			for ( AttributeType attributeRequested : apRequest.getAttributes())
			{
				//jwtClaimsBuilder = jwtClaimsBuilder.claim (attributeRequested.getFriendlyName(), null);
				jwtClaimsBuilder = jwtClaimsBuilder.claim (attributeRequested.getFriendlyName(), "");
				
			}
			
			JWTClaimsSet jwtClaims = jwtClaimsBuilder.build();
			
			// LOG initial ESMOToken just built
			//System.out.println("GOOD jwtClaims just build: " + jwtClaims.toJSONObject(true)); // there are fields to "null"
			//System.out.println("jwtClaims just build: " + jwtClaims.toString()); // without null fields
//			log.info("JWT just build: " + jwtClaims.toJSONObject(true).toString());
						
			// Sign using service account private key
			
			// Header must contain algorithm ("alg") and key ID ("kid")
			 JWSHeader jwsHeader =
			   //new JWSHeader.Builder(JWSAlgorithm.RS256).keyID("1").build(); // PrivateKeyId is alias
					 new JWSHeader.Builder(keyStoreService.getAlgorithm()).keyID(paramServ.getParam("JWT_CERT_ALIAS")).build(); 
			 
			 // Create RSA-signer with the private key
			 //JWSSigner signer = new RSASSASigner((PrivateKey) getPrivateKey());  //Local testing
			 JWSSigner signer = new RSASSASigner((PrivateKey) keyStoreService.getJWTSigningKey()); 
			 
			 SignedJWT signedJwt = new SignedJWT(jwsHeader, jwtClaims);
			 signedJwt.sign(signer);
			 
			 //ESMOToken = signedJwt.serialize();
			 //System.out.println("signedJWT compacted: " + signedJwt.serialize());

			 if (paramServ.getParam("RSA_CIPHERED_ESMOTOKEN").equals ("true")) {
				 //
				 // ENCRYPTION
				 //
				 
				// Create JWE object with signed JWT as payload
				 JWEObject jweObject = new JWEObject(
				     new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM) // Supposed the recipient accepts it TODO
				         .contentType("JWT") // required to indicate nested JWT
				         .build(),
				     new Payload(signedJwt));
	
				 // Encrypt with the recipient's public key
				 RSAKey recipientPublicJWK = null;

				 // From String to RSAPublicKey
				 byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes("UTF-8"));
				 //byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes());
				 X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
				 KeyFactory keyFactory = KeyFactory.getInstance("RSA");
				 RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
				 
				 // Convert to JWK format
				 recipientPublicJWK= new RSAKey.Builder(pubKey).build();
				 				 
				 jweObject.encrypt(new RSAEncrypter(recipientPublicJWK));
	
				 //log.info ("ESMOToken with encryption...");
				 // Serialise to JWE compact form
				 ESMOToken = jweObject.serialize();
				 //System.out.println("jweObject compacted: " + jweObject.serialize());
			 }
			 else {
				 //log.info ("ESMOToken withOUT encryption...");
				 ESMOToken = signedJwt.serialize();
			 }
			 
	    	// Update session data: POST /sm/updateSessionData
			// To store the gwCallback 			
			//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
			smConn.updateVariable(sessionId, "gwCallback", gwCallback); 
			// Anything else to be stored???
			//System.out.println("sessionId: " + sessionId);
		
		}
		catch (Exception e) {
			log.error("Exception: ", e);
		}
		
		tokenToGw.setEsMOToken(ESMOToken);
		
		
		return tokenToGw; 
		
		
	}
	
	///
	/// PRIVATE
	///
//	private Key getPrivateKey() throws KeyStoreException, FileNotFoundException, IOException,
//												   NoSuchAlgorithmException, CertificateException, 
//												   UnrecoverableKeyException, InvalidKeySpecException 
//		{
//			//[ONLY USED WHEN TESTING] 
//			ClassLoader classLoader = getClass().getClassLoader();
//			String path = classLoader.getResource("testKeys/keystore.jks").getPath();
//			KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
//			File jwtCertFile = new File(path);
//			InputStream certIS = new FileInputStream(jwtCertFile);
//			keystore.load(certIS, "keystorepass".toCharArray());
//			
//			return(keystore.getKey("1", "selfsignedpass".toCharArray()));
//			
//			
//		}

}

