package eu.esmo.gateway.gw2gw.network_api;
//package eu.esmo.httpSigs.lib.signatures;


//import eu.esmo.httpSigs.lib.enums.HttpResponseEnum;
//import eu.esmo.gateway.acm.domain.HttpResponseEnum;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
/**
 *
 * @author nikos, Atos
 */
public interface HttpSignatureService {

    public String generateSignature(String hostUrl, String method, String uri, Object postParams, String contentType, String requestId)
            throws NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, UnsupportedEncodingException, IOException, UnsupportedEncodingException;
    
    //public HttpResponseEnum verifySignature(HttpServletRequest httpRequest, Optional<PublicKey> publicKeyToCheckWith) ;
    
 
}
