package eu.esmo.gateway.gw2gw.cm_api;

import java.util.List;

//import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeTypeList;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadataList;
//import eu.esmo.gateway.gw2gw.rest_api.domain.EsmoManifest;
import eu.esmo.gateway.gw2gw.rest_api.domain.MsMetadataList;

public interface ConfMngrConnService 
{
//	public List<String> getAttributeProfiles ();
//	public AttributeTypeList getAttributeSetByProfile(String profileId);
	
	public List<String> getExternalEntities (); // returns available **collections**
	public EntityMetadataList getEntityMetadataSet (String collectionId);
	public EntityMetadata getEntityMetadata (String collectionId, String entityId);
	
	public MsMetadataList getAllMicroservices ();
	public MsMetadataList getMicroservicesByApiClass (String apiClasses); // input like "SP, IDP, AP, GW, ACM, SM, CM"
	
	public List<String> getInternalConfs (); // returns available internal configurations
	public EntityMetadata getConfiguration (String confId);
	
	//public EsmoManifest getEsmoMetadata (); //getLocalEsmoHosts
	
}

