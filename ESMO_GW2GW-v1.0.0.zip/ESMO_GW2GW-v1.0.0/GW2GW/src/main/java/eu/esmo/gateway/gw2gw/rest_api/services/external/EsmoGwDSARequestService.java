package eu.esmo.gateway.gw2gw.rest_api.services.external;

public interface EsmoGwDSARequestService {
	
	String gwDSARequest (String ESMOToken) throws Exception;

}
