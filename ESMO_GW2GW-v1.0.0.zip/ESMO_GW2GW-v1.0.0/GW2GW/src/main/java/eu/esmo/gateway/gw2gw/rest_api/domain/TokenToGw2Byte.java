package eu.esmo.gateway.gw2gw.rest_api.domain;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * bla
 */
@ApiModel(description = "bla")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-02-19T10:43:15.692Z")
@Component
public class TokenToGw2Byte   {
  @JsonProperty("esMOToken")
  private byte[] esMOToken = null;

  @JsonProperty("gwEndpoint")
  private String gwEndpoint = null;

  public TokenToGw2Byte esMOToken(byte[] esMOToken) {
    this.esMOToken = esMOToken;
    return this;
  }

  /**
   * Get esMOToken
   * @return esMOToken
  **/
  @ApiModelProperty(value = "")

//@Pattern(regexp="^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$") 
  public byte[] getEsMOToken() {
    return esMOToken;
  }

  public void setEsMOToken(byte[] esMOToken) {
    this.esMOToken = esMOToken;
  }

  public TokenToGw2Byte gwEndpoint(String gwEndpoint) {
    this.gwEndpoint = gwEndpoint;
    return this;
  }

  /**
   * Get gwEndpoint
   * @return gwEndpoint
  **/
  @ApiModelProperty(value = "")


  public String getGwEndpoint() {
    return gwEndpoint;
  }

  public void setGwEndpoint(String gwEndpoint) {
    this.gwEndpoint = gwEndpoint;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TokenToGw2Byte tokenToGw = (TokenToGw2Byte) o;
    return Objects.equals(this.esMOToken, tokenToGw.esMOToken) &&
        Objects.equals(this.gwEndpoint, tokenToGw.gwEndpoint);
  }

  @Override
  public int hashCode() {
    return Objects.hash(esMOToken, gwEndpoint);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TokenToGw {\n");
    
    sb.append("    esMOToken: ").append(toIndentedString(esMOToken)).append("\n");
    sb.append("    gwEndpoint: ").append(toIndentedString(gwEndpoint)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

