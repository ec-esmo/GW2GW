package eu.esmo.gateway.gw2gw.cm_api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.httpclient.NameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.network_api.NetworkServiceImpl;
import eu.esmo.gateway.gw2gw.params_api.KeyStoreService;
import eu.esmo.gateway.gw2gw.params_api.ParameterService;
//import eu.esmo.gateway.acm.domain.AttributeTypeList;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadataList;
//import eu.esmo.gateway.gw2gw.rest_api.domain.EsmoManifest;
import eu.esmo.gateway.gw2gw.rest_api.domain.MsMetadataList;


@Service
public class ConfMngrConnServiceImp implements ConfMngrConnService
{
	private static final Logger log = LoggerFactory.getLogger(ConfMngrConnServiceImp.class);

	private ParameterService paramServ;
	private KeyStoreService keyStoreService;
	
	private NetworkServiceImpl network = null;
	
	private final String cmUrl;
		
	@Value("${gateway.cm.getExternalEntitiesPath}")
	private String getExternalEntitiesPath;
	
	@Value("${gateway.cm.getEntityMetadataSetPath}")
	private String[] getEntityMetadataSetPath;
	
	@Value("${gateway.cm.getEntityMetadataPath}")
	private String[] getEntityMetadataPath;
	
	@Value("${gateway.cm.getAllMicroservicesPath}")
	private String getAllMicroservicesPath;
	
	@Value("${gateway.cm.getMicroservicesByApiClassPath}")
	private String[] getMicroservicesByApiClassPath;
	
	@Value("${gateway.cm.getInternalsPath}")
	private String getInternalsPath;
	
	@Value("${gateway.cm.getConfigurationPath}")
	private String[] getConfigurationPath;
	
//	@Value("${gateway.cm.getEsmoMetadataPath}")
//	private String getEsmoMetadataPath;
	
	
	@Autowired
    public ConfMngrConnServiceImp (ParameterService paramServ, KeyStoreService keyStoreServ) {
		this.paramServ = paramServ;
        cmUrl = this.paramServ.getParam("CONFIGURATION_MANAGER_URL");
        
        this.keyStoreService = keyStoreServ;
	}
	
	
//	// /ewp/esmo-metadata, AKA localEsmoHosts
//	@Override
//	public EsmoManifest getEsmoMetadata () {
//		
//		EsmoManifest result = null;
//		
//		try {
//			if (network == null)
//			{
//					network = new NetworkServiceImpl(keyStoreService);
//			}
//			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
//			
//			String jsonResult = network.sendGet (cmUrl, 
//					getEsmoMetadataPath, 
//					urlParameters, 1);
//			
//			if (jsonResult != null) {
//				log.info("Result: "+ jsonResult);
//		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//		        result = mapper.readValue(jsonResult, EsmoManifest.class);
//			}
//			
//		}
//		catch (Exception e) {
//			log.error("CM exception", e);
//			return null;
//		}
//		
//		return result;
//		
//	}
	
	// /metadata/externalEntities
	@Override
	public List<String> getExternalEntities () {
		
		// returns available **collections**
		
		List<String> result = null;
		
		try {
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet (cmUrl, 
					getExternalEntitiesPath, 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("Result: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, List.class);
			}
			
		}
		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		List<String> result;
//		
//		try {
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/externalEntities/"
//												getExternalEntitiesPath, List.class);
//		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	} 
	
	// /metadata/externalEntities/{collectionId}
	@Override
	public EntityMetadataList getEntityMetadataSet (String collectionId)
	{
		
		EntityMetadataList result = null;
		
		try {
		
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("collectionId", collectionId));
			String jsonResult = network.sendGetURIParams (cmUrl, 
					getEntityMetadataSetPath[0] + "{" + getEntityMetadataSetPath[1] + "}", 
					urlParameters, 1);
						
			if (jsonResult != null) {
				//log.info("jsonResult: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EntityMetadataList.class);
		        //log.info("Result: "+ result);
			}
		
		}
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put(getEntityMetadataSetPath[1], collectionId);
//		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		EntityMetadataList result;
//		
//		try { 
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/externalEntities/{collectionId}"
//												getEntityMetadataSetPath[0] + "{" + getEntityMetadataSetPath[1] + "}" , 
//												EntityMetadataList.class, uriVariables);
//		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
	
	// /metadata/externalEntities/{collectionId}/{entityId}
	@Override
	public EntityMetadata getEntityMetadata (String collectionId, String entityId){
		
		EntityMetadata result = null;
		
		try {
		
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("collectionId", collectionId));
			urlParameters.add(new NameValuePair("entityId", entityId));
			String jsonResult = network.sendGetURIParams (cmUrl, 
					getEntityMetadataPath[0] + "{" + getEntityMetadataPath[1] + "}" + "/{" + getEntityMetadataPath[2] + "}", 
					urlParameters, 1);
						
			if (jsonResult != null) {
				//log.info("jsonResult: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EntityMetadata.class);
			}
		
		}
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put(getEntityMetadataPath[1], collectionId);
//		uriVariables.put(getEntityMetadataPath[2], entityId);
//		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		EntityMetadata result;
//		
//		try {
//			result = restTemplate.getForObject(cmUrl + 		//"http://localhost:8080/cm/metadata/externalEntities/{collectionId}/{entityId}"
//												getEntityMetadataPath[0] + "{" + getEntityMetadataPath[1] + "}"+ "/{" + getEntityMetadataPath[2] + "}" , 
//												EntityMetadata.class, uriVariables);
//		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
	
	
	
	
	// /metadata/microservices
	@Override
	public MsMetadataList getAllMicroservices (){
		
		MsMetadataList result = null;
		
		try {
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet (cmUrl, 
					getAllMicroservicesPath, 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("jsonResult: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, MsMetadataList.class);
		        //log.info("Result: "+ result);
			}
			
		}

//		RestTemplate restTemplate = new RestTemplate();
//		
//		MsMetadataList result;
//		
//		try {
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/microservices/"
//												getAllMicroservicesPath, MsMetadataList.class);
//		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}

		return result;
	}
	
	// /metadata/microservices/{apiClass}
	@Override
	public MsMetadataList getMicroservicesByApiClass (String apiClasses)//throws UnrecoverableKeyException, KeyStoreException, FileNotFoundException, NoSuchAlgorithmException, CertificateException, InvalidKeySpecException, IOException
	{
		// input like "SP, IDP, AP, GW, ACM, SM, CM"
		
		MsMetadataList result = null;
		
		try {
		
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("apiClass", apiClasses));
			String jsonResult = network.sendGetURIParams (cmUrl, 
					getMicroservicesByApiClassPath[0] + "{" + getMicroservicesByApiClassPath[1] + "}", 
					urlParameters, 1);
			
	//		String jsonResult = network.sendGet (cmUrl, 
	//				getMicroservicesByApiClassPath[0] + apiClasses, 
	//				urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("jsonResult: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, MsMetadataList.class);
		        //log.info("Result: "+ result);
			}
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put("apiClass", apiClasses);
//		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		
//		
//		try {
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/microservices/{apiClass}"
//												getMicroservicesByApiClassPath[0] + "{" + getMicroservicesByApiClassPath[1] + "}" ,
//												MsMetadataList.class, uriVariables);
		
		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	} 
	
	// /metadata/internal
	@Override
	public List<String> getInternalConfs () {
		
		// returns available **internal configurations**
		
		List<String> result = null;
		
		try {
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			String jsonResult = network.sendGet (cmUrl, 
					getInternalsPath, 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("jsonResult: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, List.class);
		        //log.info("Result: "+ result);
			}
			
		}
		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		List<String> result;
//		
//		try {
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/internal/"
//												getInternalsPath, List.class);
//		}
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	} 
	
	// /metadata/internal/{confId}
	@Override
	public EntityMetadata getConfiguration (String confId)
	{
		EntityMetadata result = null;
		
		try {
			if (network == null)
			{
					network = new NetworkServiceImpl(keyStoreService);
			}
			List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
			
			urlParameters.add(new NameValuePair("confId", confId));
			String jsonResult = network.sendGetURIParams (cmUrl, 
					getConfigurationPath[0] + "{" + getConfigurationPath[1] + "}", 
					urlParameters, 1);
			
			if (jsonResult != null) {
				//log.info("jsonResult: "+ jsonResult);
		        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		        result = mapper.readValue(jsonResult, EntityMetadata.class);
		        //log.info("Result: "+ result);
			}
			
		}
		
//		Map<String, String> uriVariables = new HashMap<>();
//		uriVariables.put(getConfigurationPath[1], confId);
//		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		EntityMetadata result;
//		
//		try { 
//			result = restTemplate.getForObject( cmUrl + 	//"http://localhost:8080/cm/metadata/internal/{confId}"
//												getConfigurationPath[0] + "{" + getConfigurationPath[1] + "}" , 
//												EntityMetadata.class, uriVariables);
//		}
		
		catch (Exception e) {
			log.error("CM exception", e);
			return null;
		}
		
		return result;
	}
	
//	
//	///
//	/// PRIVATE
//	///
//	private void createHttpSigService() throws KeyStoreException, FileNotFoundException, IOException,
//	   NoSuchAlgorithmException, CertificateException, 
//	   UnrecoverableKeyException, InvalidKeySpecException 
//	{
//		String fingerPrint = "7a9ba747ab5ac50e640a07d90611ce612b7bde775457f2e57b804517a87c813b";
//		
//		//ClassLoader classLoader = getClass().getClassLoader();
//		//String path = classLoader.getResource("testKeys/keystore.jks").getPath();
//		
//		/*
//		ClassPathResource resource = new ClassPathResource("testKeys/keystore.jks");
//		InputStream certIS = resource.getInputStream();
//		
//		KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
//		keystore.load(certIS, "keystorepass".toCharArray());
//		
//		Key signingKey = keystore.getKey("1", "selfsignedpass".toCharArray());
//		
//		httpSigService = new HttpSignatureServiceImpl(fingerPrint, signingKey);
//		*/
//		
//		Key signingKey = this.keyStoreService.getSigningKey();
//		this.httpSigService = new HttpSignatureServiceImpl(fingerPrint, signingKey);
//	} 
	
}