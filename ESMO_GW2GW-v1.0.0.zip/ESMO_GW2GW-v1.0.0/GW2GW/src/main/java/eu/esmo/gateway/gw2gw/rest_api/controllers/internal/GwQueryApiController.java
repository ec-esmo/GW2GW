package eu.esmo.gateway.gw2gw.rest_api.controllers.internal;

import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.rest_api.domain.TokenToGw;
import eu.esmo.gateway.gw2gw.rest_api.services.internal.GwQueryService;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;

import io.swagger.annotations.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import javax.servlet.http.HttpServletRequest;
@javax.annotation.Generated(value = "eu.esmo.gateway.gw2gw.codegen.languages.SpringCodegen", date = "2019-02-04T13:09:09.939Z")

@Controller
//public class GwQueryApiController implements GwQueryApi {
public class GwQueryApiController {
	
	@Autowired
	private GwQueryService gwQueryService;
	
	@Autowired
	private SessionManagerConnService smConn;
	
	
	

    private static final Logger log = LoggerFactory.getLogger(GwQueryApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;
    

    @org.springframework.beans.factory.annotation.Autowired
    public GwQueryApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }
    
    
    @ApiOperation(value = "FOR TESTING: Returns a token from SM", nickname = "gwToken", notes = "FOR TESTING: Returns a token from SM", tags={ "Internal GWms APIs", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Request admitted"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/gw/token",
        produces = { "application/x-www-form-urlencoded" },
        method = RequestMethod.GET)
    public ResponseEntity<String> gwToken() {
    	
    	// Start Session: POST /sm/startSession
    	String sessionId;
    	String msToken = null;
		try {
			sessionId = smConn.startSession();
			msToken = smConn.generateToken(sessionId);
		} catch (UnrecoverableKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return new ResponseEntity<String>(msToken, HttpStatus.OK);
    }

    @ApiOperation(value = "Pass a standard request object to be handled.", nickname = "gwQuery", notes = "Process a DSA request from the ACM to be sent to the remote GW. Such request can contain the remote AP just discovered or not (to be discovered in the remote GW).", tags={ "Internal GWms APIs", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Request admitted"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/gw/query",
        consumes = { "application/x-www-form-urlencoded" },
        method = RequestMethod.POST)
    public String gwQuery(@ApiParam(value = "The security token for ms to ms calls", required=true) @RequestParam(value="msToken", required=true)  String msToken,
    			Model model) {
    //public ResponseEntity<Void> gwQuery(@ApiParam(value = "The security token for ms to ms calls", required=true) @RequestParam(value="msToken", required=true)  String msToken) {
    
    	// Validate msToken: GET /sm/validateToken
	    	// Responds by code: OK, sessionData.sessionId the sessionId used to generate the jwt, 
	    	// and additionalData: extraData that were used to generate the jwt
    	
    	
    	// **Jump to GWQueryServiceImp
    	// Get SessionData: GET /sm/getSessionData
    	// Get apRequest (AttributeSet), apMetadata (EntityMetadata), authenticationSet (AttributeSet)
	    	// Note: Keep the apEntityId variable along with the spRequest in the terminating GW acm/attributes/request
	        // so to easily identify that this is a request from the oGW (not from an SP) and thus act accordingly 
    	
    	// LOG sessionData just obtained
    	
    	// **The authenticationSet is supposed to be complete.
    		// The identity claims that can be sent in the token are any of the eIDAS Mininimum Dataset, 
    		// but should include at least the PersonIdentifier.
    	// **The dsa claims are supposed to be right (belonging to one of the schemes managed in ESMO project:
			// eIDAS MDS claims
			// eduGAIN claims
			// eduOrg claims
			// SCHAC claims
    	
    	// Build ESMOToken (dsaRequest) 
    	
    	// LOG ESMOToken just built
    	
    	// Update session data: POST /sm/updateSessionData
    		// Passed data is stored in a session variable overwriting the previous value. 
    		// If no session variable is given, then the whole data stored in this session will be replaced with the passed dataObject. 
    		// In that case the dataObject must be a dictionary containing pairs of key, values e.g. {key1:value1, key2:value2} 
    		// with keys and values strings (the latter may be json)
    		// Responds by setting code = OK "
    	// To store the GWcallbackRef_ID (this name is indicative, but must be unique per session, 
    	// so can include the ms identity as prefix). UUID of this GW2GW ms in a GW2GW_ID_SESSION_VAR
    	// Is this in the ESMOtoken? I think so...
    	
    	// Return from GWQueryServiceImp
    	
    	// Redirect to remote /esmo/gw/dsaRequest
    	
    	// END
    	
    	//String accept = request.getHeader("Accept");
    	String contentType = request.getHeader("Content-type");
    	if (contentType != null && contentType.contains("application/x-www-form-urlencoded")) {
        	
	        try {
	        	
	        	// Validate msToken: GET /sm/validateToken
	        	
	        	String sessionId ="";
	        	
	        	//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
	        	sessionId = smConn.validateToken(msToken);
	        	 
	        	if (sessionId != "") {
	        	// msToken validated	
	       
	        	//System.out.println ("We are in /gw/query with token: " + msToken); 	
	        	
	        	//Build ESMOToken (dsaRequest). Update session data.
	        	TokenToGw tokenToGw = gwQueryService.gwQuery(smConn, sessionId);
	    		
	        	String esMOToken = tokenToGw.getEsMOToken();
	    		String gwUrl = tokenToGw.getGwEndpoint();
	    		
	    		if (esMOToken!=null && gwUrl != null) {
		        	
		        	model.addAttribute("esMOToken", esMOToken);
		        	model.addAttribute("msUrl", gwUrl);
		        	
		            return "esmogwform";
		        	//return new ResponseEntity<Void>(HttpStatus.OK);
	    		}
	    		else  {
	    			log.error("Error generating the ESMOtoken: "+ esMOToken + "/n Or the gwUrl: " + gwUrl);
	    			return "error";
	    		}
	    		
	        	}
	        	else  {
	        		log.error("msToken not validated");
	        		return "error";
	        	}
	        	
	        }
	        catch (Exception e) {
	            log.error("Exception: ", e);
	        	
	            return "error";
	        	//return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
	        }
        
    	}
        
    	log.error("Bad content-type.");
    	return "error";
    	//return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }


}
