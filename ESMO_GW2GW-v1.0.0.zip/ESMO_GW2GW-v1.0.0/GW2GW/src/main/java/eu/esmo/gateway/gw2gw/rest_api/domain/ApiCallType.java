package eu.esmo.gateway.gw2gw.rest_api.domain;

import com.fasterxml.jackson.annotation.JsonValue;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets apiCallType
 */
public enum ApiCallType {
  
	acmRequest("acmRequest"),
  
	acmResponse("acmResponse"),
  
	handleResponse("handleResponse"),
  
	authenticate("authenticate"),
  
	query("query"),
  
	registry("registry"),
  
	startDiscovery("startDiscovery"),
  
	process("process"),
  
	startSession("startSession"),
  
	updateSessionData("updateSessionData"),
  
	getSessionData("getSessionData"),
  
	generateToken("generateToken"),
  
	validateToken("validateToken"),
	
	microservices("microservices"),
	
	attributes("attributes"),
	
	externalEntities("externalEntities");

  private String value;

  ApiCallType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ApiCallType fromValue(String text) {
    for (ApiCallType b : ApiCallType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}

