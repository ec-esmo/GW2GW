package eu.esmo.gateway.gw2gw.rest_api.services.external;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import eu.esmo.gateway.gw2gw.cm_api.ConfMngrConnService;
import eu.esmo.gateway.gw2gw.configuration.Constants;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSet;
import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeType;
import eu.esmo.gateway.gw2gw.rest_api.domain.EndpointType;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadata;
import eu.esmo.gateway.gw2gw.rest_api.domain.EntityMetadataList;
import eu.esmo.gateway.gw2gw.rest_api.domain.SecurityKeyType;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;
import eu.esmo.gateway.gw2gw.params_api.KeyStoreService;
import eu.esmo.gateway.gw2gw.params_api.ParameterService;

@Service
public class EsmoGwDSARequestServiceImp implements EsmoGwDSARequestService{
	
	private static final Logger log = LoggerFactory.getLogger(EsmoGwDSARequestServiceImp.class);
	
	private AttributeSet spRequest;
	
	private String apEntityId = null;
			
	private EntityMetadata spMetadata;
	
	private EntityMetadata idpMetadata;
			
	private AttributeSet authenticationSet;
	
	@Autowired
	private SessionManagerConnService smConn;
	
	@Autowired
	private ConfMngrConnService confMngrConnService;
	
	@Autowired
	private KeyStoreService keyStoreService;
	
	@Autowired
	private ParameterService paramServ;
	
	@Override
	public String gwDSARequest (String ESMOToken)  throws Exception {
				
		//System.out.println ("We are in /esmo/gw/dsaRequest with token: " + ESMOToken);	
		
		String msToken = null;
		
		try {
		
		
    	// Example of a dsaRequest JWT:
		// Entity Id or Endpoints??! MetadataEntityId
	
		// NEWer:
//		"iss":"https://origGWurl.com", 
//		"aud":["https://destGWuEntityId.com"],  // EntityId info
//		"iat": "1364292137871",
//		"exp": "1364293137871",
//		"nbf": "1364292537871",
//		"jti":"345a7bab-de06-4695-a2dd-9d8d6b40e443",   //Callback reference
//		"spEntityId": "https://www.strath.ac.uk/ServiceProvider/metadata",
//		"apEntityId": "https://esmo.uji.es/AttributeProvider/metadata",
//		"IDP_entityId": "https://pasarela.clave.gob.es/ProxyClave2/ServiceProvider/metadata"
//		"IDP_defaultDisplayName" : {"Clave Gateway eIDAS SPAIN"}, // To idpMetadata
//		"eIDAS_loa": "http://eidas.europa.eu/LoA/high",
//		"eIDAS_PersonIdentifier":["ES/AT/02635542Y"], 
//		"eIDAS_FamilyName":["Jones Welsh","J Welsh"], 
//		"eduPersonAffiliation":null,
//		"eduPersonOrgUnitDN":null,
//		"schacHomeOrganization":null

			
			
			SignedJWT signedJwt = null;
			
			if (paramServ.getParam("RSA_CIPHERED_ESMOTOKEN").equals ("true")) {
				
				//
				//Decipher
				//
				
				//log.info ("ESMOToken with encryption...");
				
				// Parse the JWE string
				JWEObject jweObject = JWEObject.parse(ESMOToken);
	
				// Decrypt with private key
				jweObject.decrypt(new RSADecrypter((PrivateKey) keyStoreService.getJWEKey()));
	
				// Extract payload
				signedJwt = jweObject.getPayload().toSignedJWT();
				
				if (signedJwt == null) {
					log.error("Payload is not a signed JWT!");
					return null;
				}
					
			}
			else  {
				//log.info ("ESMOToken withOUT encryption...");
				signedJwt = SignedJWT.parse(ESMOToken);
			}
		
			// Validation of the JWT		
			// To parse the JWS and verify it, e.g. on client-side
			
			//SignedJWT signedJwt = SignedJWT.parse(ESMOToken);
			
			
			
			JWTClaimsSet jwtClaims = signedJwt.getJWTClaimsSet();
			
	    	// Extract info to build the following:
	    	// * spRequest, 
	    	// * spMetadata (1. spEntityId, 2. oGW apiCallback endpoint address), TO ASK--> YES, necessary 
	    	// * apEntityId (it could be null, so the tACM could invoke the MultiUI
	    	// * authenticationSet
			// * idpMetadata 
			
				apEntityId = jwtClaims.getStringClaim ("apEntityId"); // It could be null. NO
					
				spRequest = new AttributeSet();
				//spRequest.setId(jwtClaims.getStringClaim ("jti"));  // The oGw callback
				spRequest.setId(jwtClaims.getJWTID());
				
				spRequest.setIssuer (jwtClaims.getStringClaim ("spEntityId"));
				
				
				spRequest.setType(AttributeSet.TypeEnum.REQUEST);
				// If apEntityId is not null, what to do?? recipient = apEntityId
				spRequest.setRecipient (jwtClaims.getStringClaim ("apEntityId") != null ? jwtClaims.getStringClaim ("apEntityId") : jwtClaims.getStringClaim ("aud"));	
				
				spMetadata = new EntityMetadata();
				spMetadata.setEntityId(jwtClaims.getStringClaim ("spEntityId"));
				
				EntityMetadataList myGWentityList = confMngrConnService.getEntityMetadataSet("rGW");
				String originGWId = jwtClaims.getIssuer();
				
				//log.info ("originGWId:" + originGWId);
				
				boolean found = false;
				String publicK = null;
				String originGWurl = null;
				List<EndpointType> endpoints = new ArrayList<EndpointType> ();
				List<String> microservices = new ArrayList<String> ();
				List<SecurityKeyType> secKeys = new ArrayList<SecurityKeyType> ();
				for (EntityMetadata gw : myGWentityList) {
					if (gw.getEntityId().equals(originGWId) ) {
						
						// Select the recipient public key
						for (SecurityKeyType secKey : gw.getSecurityKeys()) {
							if (secKey.getUsage().equals(SecurityKeyType.UsageEnum.SIGNING)) {
								publicK = secKey.getKey();
								//System.out.println ("publicK:" + publicK);
							}
						}
						
						// Get the microservices
						for (String ms : gw.getMicroservice())
							microservices.add (ms);
						
						// Get the securityKeys
						for (SecurityKeyType secKey : gw.getSecurityKeys())
							secKeys.add (secKey);
						  
						List<EndpointType> myEndPoints = gw.getEndpoints();
						for (EndpointType endPoint : myEndPoints) {
							endpoints.add(endPoint);
							
							if (!found && (endPoint.getType().equals(Constants.ESMO_GW_DSAREQUEST))) {
								originGWurl = endPoint.getUrl();
								found = true;
								//break;
							}
						}
						if (found) break;
					}
				}
				if (publicK == null) {
					 log.error("No origin GW public key to validate the signature of the ESMOToken!");
					 return null;
				 }
				
//				EndpointType originGW = new EndpointType();
//				originGW.setUrl(originGWurl); 
//				originGW.setMethod("HTTP-POST");
//				originGW.setType(Constants.ESMO_GW_DSARESPONSE); 
//				endpoints.add(originGW);
				
				spMetadata.setEndpoints(endpoints);
				spMetadata.setMicroservice(microservices);
				spMetadata.setSecurityKeys(secKeys);
				
				authenticationSet = new AttributeSet();
				authenticationSet.setId(Constants.ESMO_GW2GW_PREFIX + UUID.randomUUID().toString());
				authenticationSet.setIssuer (jwtClaims.getStringClaim("IDP_entityId"));
				authenticationSet.setType(AttributeSet.TypeEnum.AUTHRESPONSE);
				// If apEntityId is not null, what to do?? recipient = apEntityId
				authenticationSet.setRecipient (jwtClaims.getStringClaim ("apEntityId") != null ? jwtClaims.getStringClaim ("apEntityId") : jwtClaims.getStringArrayClaim("aud")[0]); 

				List<AttributeType> myAuthAttributes =  new ArrayList<AttributeType>();
				List<AttributeType> mySpAttributes =  new ArrayList<AttributeType>();
				String key= "";
				int authCounter = 0;
				int counter = 0;
				String withoutBracketsEtAll;
				for ( Map.Entry<String, Object> entry : jwtClaims.getClaims().entrySet()) {
					
					
		             key = entry.getKey();
		             //log.info ("key:" + key);
		             //log.info ("value:" + entry.getValue());
		             
		             if (key.startsWith("eIDAS_")) {
		            	 AttributeType anAuthAttribute = new AttributeType ();
		            	 anAuthAttribute.setFriendlyName(key.substring(6)); //strlen ("eIDAS_")
		            	 withoutBracketsEtAll= "";
		            	 withoutBracketsEtAll = entry.getValue()!=null ? entry.getValue().toString() : null;
		            	 if (withoutBracketsEtAll != null) {
		            		 withoutBracketsEtAll = withoutBracketsEtAll.replaceAll("\\[|\\]", "");    
		            		 withoutBracketsEtAll = withoutBracketsEtAll.replaceAll("^\"|\"$", "");
		            		 withoutBracketsEtAll = withoutBracketsEtAll.replaceAll ("\\\\","");
		            	 }
		            	 //log.info ("withoutBracketsEtAll: " + withoutBracketsEtAll);
		            	 anAuthAttribute.addValuesItem(withoutBracketsEtAll);
		            	 myAuthAttributes.add(authCounter++, anAuthAttribute);
		             }
		             //if ((entry.getValue() == null) && !(key.equals("apEntityId"))) {
		             if (entry.getValue().equals("")) {
		            	 AttributeType anAttribute = new AttributeType ();
		            	 anAttribute.setFriendlyName(key);
		            	 anAttribute.addValuesItem(null);
		            	 mySpAttributes.add(counter++, anAttribute);
		             }
		            
		        }
				//log.info ("counter of attr requested: " + counter);
				
				authenticationSet.setAttributes(myAuthAttributes);
				spRequest.setAttributes(mySpAttributes);
				
				idpMetadata = new EntityMetadata();
				idpMetadata.setEntityId(jwtClaims.getStringClaim("IDP_entityId"));
				idpMetadata.setDefaultDisplayName(jwtClaims.getStringClaim ("IDP_defaultDisplayName"));
				
				
				// LOG the above variables just extracted.
//				log.info("Data obtained to be stored in the Session ...");
//				log.info ("spRequest:" + "\n" + spRequest.toString());
//				log.info ("spMetadata:" + "\n" + spMetadata.toString());
//				log.info ("apEntityId:" + "\n" + apEntityId.toString());
//				log.info ("authenticationSet:" + "\n" + authenticationSet.toString());
//				log.info ("idpMetadata:" + "\n" + idpMetadata.toString());
				
			// Info extracted already.
			
			//
			// Verification of the ESMOToken
			//
				// Verify the signature with the issuer's public key
				 
				 // From String to RSAPublicKey
				 //byte[] publicBytes = Base64.getDecoder().decode(publicK);
				 byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes("UTF-8"));
				 //byte[] publicBytes = Base64.getDecoder().decode(publicK.getBytes());
				 X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
				 KeyFactory keyFactory = KeyFactory.getInstance("RSA");
				 RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(keySpec);
		        
				 
			JWSVerifier verifier = new RSASSAVerifier(pubKey);
			//JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) keyStoreService.getJWTPublicKey()); 
			//JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) getPublicKey()); // Local testing
			if (signedJwt.verify(verifier)) {
				
				log.info ("ESMOToken signature verified! Expiration time is not validated yet.");
				//jwtClaims.getExpirationTime()
				
		    	// Validate the JWT
				
				// Check the audience. It could be the gw entity Id or the ap entity id... Mmmmm TO ASK: they are entityIDs?? YES
				// Therefore, FROM THE ConfMngr: to check both files and if not found then reject the jwt
				boolean validated = false;
				List<String> audience = jwtClaims.getAudience();
				
				// It's me or one of my APs
				EntityMetadata myInternalConf = confMngrConnService.getConfiguration("LGW");
				if (myInternalConf!=null) {
				 String me = myInternalConf.getEntityId();
				 for (String entityId : audience) {
					if (entityId.equals(me)) {
						validated = true;
						break;
					}
					
				 }
				}
				
				if (!validated) {
					EntityMetadataList myAPs = confMngrConnService.getEntityMetadataSet("AP");
					if (myAPs != null) {
					 for (String entityId : audience) {
						for (EntityMetadata myAP : myAPs) {
							if (myAP.getEntityId().equals(entityId)) {
								validated = true;
								break;
							}
						}
						if (validated) break;
					 }
					}
					
				}
				if (!validated) {
					log.error("Audience: " + audience.toString() + " is not authorised.");
					return msToken;
				}
				
		    	// Check the issuer, among the ones allowed:
				// 1.- Check that the entity ID belongs to the entityID of ESMO gateways published in 
				// EWP Registry / EntityMetadata of that GW 
				validated = false;
				//String originGWId = jwtClaims.getIssuer();
				//EntityMetadataList myGWentityList = confMngrConnService.getEntityMetadataSet("rGW");
				if (myGWentityList!= null) {
				 for (EntityMetadata myGWentity : myGWentityList) {
					if (myGWentity.getEntityId().equals(originGWId)) {
					
							validated = true;
							break;
					}
				 }
				}
				if (!validated) {
					
					log.error("Issuer " + originGWId + " is not authorised.");
					return msToken;
				}		
				
				// Other validations: times	
				validated = false;
				//TODO
				//jwtClaims.getIssueTime()
				//jwtClaims.getNotBeforeTime()
				
	    	// Start Session: POST /sm/startSession
			String sessionId = smConn.startSession();
	    		
	    	// Update session data: POST /sm/updateSessionData
	    	// To store spRequest with the apEntityId if any, --NO spMetadata-- oGW apiCallback endpoint address,authenticationSet   
			
			
			ObjectMapper objSpRequest = new ObjectMapper();
			smConn.updateVariable(sessionId,"spRequest",objSpRequest.writeValueAsString(spRequest));
			
			ObjectMapper objSpMetadata = new ObjectMapper();
			smConn.updateVariable(sessionId,"spMetadata",objSpMetadata.writeValueAsString(spMetadata));
			
			ObjectMapper objApEntityId = new ObjectMapper();
			smConn.updateVariable(sessionId,"apEntityId",objApEntityId.writeValueAsString(apEntityId));
			
			ObjectMapper objAuthenticationSet = new ObjectMapper();
			smConn.updateVariable(sessionId,"authenticationSet",objAuthenticationSet.writeValueAsString(authenticationSet));
			
			ObjectMapper objIdpMetadata = new ObjectMapper();
			smConn.updateVariable(sessionId,"idpMetadata",objIdpMetadata.writeValueAsString(idpMetadata));
				
//			ObjectMapper objOgwId = new ObjectMapper();
//			smConn.updateVariable(sessionId,"originGwId",objOgwId.writeValueAsString(oGwId));
	    	
			// Create msToken: GET /sm/generateToken
			msToken = smConn.generateToken(sessionId);
			
			}
			else {
				log.error("ESMOToken signature NOT verified!");
			}
		}
		catch (Exception e) {
			log.error("Exception: ", e);
		}
				
		return msToken;
		
	}
	
	///
	/// PRIVATE
	///
//	private Key getPublicKey() throws KeyStoreException, FileNotFoundException, IOException,
//													   NoSuchAlgorithmException, CertificateException, 
//													   UnrecoverableKeyException, InvalidKeySpecException 
//		{
//			//[ONLY USED WHEN TESTING] 
//			ClassLoader classLoader = getClass().getClassLoader();
//			String path = classLoader.getResource("testKeys/keystore.jks").getPath();
//			KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
//			File jwtCertFile = new File(path);
//			InputStream certIS = new FileInputStream(jwtCertFile);
//			keystore.load(certIS, "keystorepass".toCharArray());
//				
//			Key key = keystore.getKey("1", "selfsignedpass".toCharArray());
//			
//			if (key instanceof PrivateKey) {
//		          // Get certificate of public key
//		          Certificate cert = keystore.getCertificate("1");
//		          // Get public key
//		          PublicKey publicKey = cert.getPublicKey();
//
//		          //String publicKeyString = Base64.encodeBase64String(publicKey
//		          //          .getEncoded());
//		          String publicKeyString = publicKey.toString();
//		          //System.out.println("PublicKey: "+ publicKeyString);
//		          
//		          return publicKey;
//
//		        }
//			else return null;	
//				
//		}

}

