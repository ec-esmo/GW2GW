package eu.esmo.gateway.gw2gw.utils;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.rest_api.domain.AttributeSet;

public class CommonUtils 
{
	 public String getStringFromFile(String fileName)
	 {
        StringBuilder result = new StringBuilder("");
        //Get file from resources folder
        ClassLoader classLoader = getClass().getClassLoader();
		String path = classLoader.getResource(fileName).getPath();
		
		
        //ClassLoader classLoader = getClass().getClassLoader();
        File file;
        //System.out.println("getStringFromFile "+fileName+ " path:"+path.toString());
        file = new File(path);
       
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                result.append(line).append("\n");
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result.toString();
	}
	
	public static AttributeSet makeAttributeSetFromJSON(String json) throws IOException 
	{
		ObjectMapper mapper = new ObjectMapper();
		//ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//	        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	    return mapper.readValue(json, AttributeSet.class);
	}
	
	
	public AttributeSet getAttributeSetFromFile(String filename)
	{
		String stJson = getStringFromFile(filename);
		
		try {
			return makeAttributeSetFromJSON(stJson);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}

}