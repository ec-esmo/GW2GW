package eu.esmo.gateway.gw2gw.rest_api.domain;

import com.fasterxml.jackson.annotation.JsonValue;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets apiConnectionType
 */
public enum ApiConnectionType {
  
	post("post"),
  
	get("get"),
  
	direct("direct");

  private String value;

  ApiConnectionType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ApiConnectionType fromValue(String text) {
    for (ApiConnectionType b : ApiConnectionType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}