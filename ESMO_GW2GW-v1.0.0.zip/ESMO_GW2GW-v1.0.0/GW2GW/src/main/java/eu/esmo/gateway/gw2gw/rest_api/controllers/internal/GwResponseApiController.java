package eu.esmo.gateway.gw2gw.rest_api.controllers.internal;

import com.fasterxml.jackson.databind.ObjectMapper;

import eu.esmo.gateway.gw2gw.rest_api.domain.TokenToGw;
import eu.esmo.gateway.gw2gw.rest_api.services.internal.GwResponseService;
import eu.esmo.gateway.gw2gw.sm_api.SessionManagerConnService;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
@javax.annotation.Generated(value = "eu.esmo.gateway.gw2gw.codegen.languages.SpringCodegen", date = "2019-02-04T13:09:09.939Z")

@Controller
//public class GwResponseApiController implements GwResponseApi {
public class GwResponseApiController {
	
	@Autowired
	private GwResponseService gwResponseService;
	
	@Autowired
	private SessionManagerConnService smConn;	

    private static final Logger log = LoggerFactory.getLogger(GwResponseApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public GwResponseApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    
    @ApiOperation(value = "Callback. Pass a standard response object to be handled.", nickname = "gwResponse", notes = "Process a DSA response from the ACM to send it back to the remote GW.", tags={ "Internal GWms APIs", })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Request admitted"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 401, message = "Not authorised") })
    @RequestMapping(value = "/gw/response",
        consumes = { "application/x-www-form-urlencoded" },
        method = RequestMethod.POST)
    public String gwResponse(@ApiParam(value = "The security token for ms to ms calls", required=true) @RequestParam(value="msToken", required=true)  String msToken,
    			Model model) {
    //public ResponseEntity<Void> gwResponse(@ApiParam(value = "The security token for ms to ms calls", required=true) @RequestParam(value="msToken", required=true)  String msToken) {
   
    	// Validate msToken: GET /sm/validateToken
	    	// Responds by code: OK, sessionData.sessionId the sessionId used to generate the jwt, 
	    	// and additionalData: extraData that were used to generate the jwt
    	
    	//**Jump to GwResponseServiceImp
    	// Get SessionData: GET /sm/sessionData
    	// Get responseAssertions (AttributeSetList), 
    	// and where is the oGW callback?? in that attributeSetList
    	
    	// LOG the responseAssertions just obtained.
    	
    	// Build ESMOToken (dsaResponse) with the attribute assertions   
    	
    	// Return from GwResponseServiceImp
    	
    	// Delete session: POST /sm/deleteSession
    	
    	// Redirect to /esmo/gw/dsaResponse
    	
    	// END
        
    	
    	//String accept = request.getHeader("Accept");
    	String contentType = request.getHeader("Content-type");
    	if (contentType != null && contentType.contains("application/x-www-form-urlencoded")) {
        	
	        try {
	        	// Validate msToken: GET /sm/validateToken
	        	String sessionId = "";
	        	
	        	//UNAUTHORIZED, NOT_FOUND, FORBIDDEN
	        	sessionId = smConn.validateToken(msToken);
	        	
	        	if (sessionId!= "") {
	        	// msToken validated
	        	
	        	//System.out.println ("We are in /gw/response with token: " + msToken);      	
	        	
	        	//Build ESMOToken. 
	        	TokenToGw tokenToGw = gwResponseService.gwResponse(smConn, sessionId);
	        	String esMOToken = tokenToGw.getEsMOToken();
	        	
	        	if (esMOToken != null) {
		        	// Delete session: POST /sm/deleteSession
	        		
	        // If TESTING, comment the following deleteSession	
	        		smConn.deleteSession(sessionId);
	        		//System.out.println ("DELETING SESSION ----");
		        	
		        	String gwUrl = tokenToGw.getGwEndpoint();
		        	
		        	if (gwUrl != null) {
		        		
		        		model.addAttribute("esMOToken", esMOToken);
		        		model.addAttribute("msUrl", gwUrl);
		            
		        		return "esmogwform";
		        		//return new ResponseEntity<Void>(HttpStatus.OK);
		        	}
		    		else {
		    			log.error("Error getting the msUrl: " + gwUrl);		
		    			return "error";
		    		}
	        	}
	        	else {
	        		log.error("Error generating the ESMOtoken: " + esMOToken);
	        		return "error";
	        	}
	        	
	        	}
	        	else {
	        		log.error("msToken not validated");
	        		return "error";
	        	}
	        }
	        catch (Exception e) {
	            log.error("Exception: ", e);
	        	
	            return "error";
	        	//return new ResponseEntity<Void>(HttpStatus.UNAUTHORIZED);
	        }
        
    	}
        
    	log.error("Bad content-type.");
    	return "error";
    	//return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        
    }

}
