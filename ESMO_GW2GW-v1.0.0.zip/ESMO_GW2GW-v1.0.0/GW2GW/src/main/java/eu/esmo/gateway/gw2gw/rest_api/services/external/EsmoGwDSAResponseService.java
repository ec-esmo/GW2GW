package eu.esmo.gateway.gw2gw.rest_api.services.external;

public interface EsmoGwDSAResponseService {
	
	String gwDSAResponse (String ESMOToken) throws Exception;

}
